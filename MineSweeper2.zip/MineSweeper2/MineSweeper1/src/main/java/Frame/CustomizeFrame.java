package Frame;

import MineBean.MineImage;
import MineBean.MineType;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import Frame.GameFrame;
import MineArithmetic.Arithmetic.GridType;
import java.net.URL;

import java.net.URL;

public class CustomizeFrame extends Application {

    private GridType gridType;
    int row = 0;
    int col = 0;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("自定义页面");

        BorderPane root = new BorderPane();
        // 创建 ImageView 并设置背景图片
        ImageView background = new ImageView(new Image("file:///D:/IDEA/MineSweeper1/src/main/resources/images/1.jpg"));
        background.setFitWidth(512); // 设置宽度
        background.setFitHeight(512); // 设置高度
        background.setOpacity(0.4); // 设置透明度
        // 将背景 ImageView 添加到根节点
        root.getChildren().add(background);
        root.setTop(topLayout());
        root.setCenter(centerLayout(primaryStage));

        Scene scene1 = new Scene(root, 512, 512);
        URL url = getClass().getResource("/customize.css");
        if (url != null) {
            scene1.getStylesheets().add(url.toExternalForm());
//            System.out.println("found it!");
        } else {
            System.out.println("Resource not found: customize.css");
        }

        primaryStage.setScene(scene1);
        primaryStage.show();
    }
    public HBox topLayout() {
        HBox pane = new HBox(10); //间距为10
        pane.setPadding(new Insets(15,12,15,12));
        pane.setAlignment(Pos.CENTER);
        pane.getStyleClass().add("top-pane"); // 添加背景颜色的样式
        // 创建logo并设置图像
        Label logo = new Label();
        setLabelImage(logo, MineType.MINE_LOGO);
        Label CustomiazeLabel = new Label("CUSTOMIZE MODE");
        CustomiazeLabel.getStyleClass().add("selection-label");
        // 使用一个Region作为左边和右边的占位符
        Region leftSpacer = new Region();
//        leftSpacer.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        Region rightSpacer = new Region();
        leftSpacer.setPrefWidth(80);
        HBox.setHgrow(rightSpacer, Priority.ALWAYS);

        pane.getChildren().addAll(logo,leftSpacer,CustomiazeLabel,rightSpacer);
        return pane;
    }
    public void setLabelImage(Label label, int flag) {
        if (label == null) {
            return;
        }
        ImageView icon = MineImage.getImageView(100, 100, flag);
        icon.setFitWidth(40); //长
        icon.setFitHeight(40); //宽
        label.setGraphic(icon);
    }

    public VBox centerLayout(Stage primaryStage){
        VBox centerlayout = new VBox(40);
        centerlayout.setPadding(new Insets(20));
        centerlayout.setAlignment(Pos.CENTER);

        HBox Gridsize = new HBox(20);
        Label gridsize = new Label("Grid Size:");
        Label gridsizeX = new Label("X");
        gridsize.getStyleClass().add("label");
        gridsizeX.getStyleClass().add("label");
        TextField textField1 = new TextField();
        TextField textField2 = new TextField();
        textField1.getStyleClass().add("text-field");
//        textField1.setPrefWidth(75); // 设置文本框的宽度为150像素
//        textField2.setPrefWidth(75); // 设置文本框的宽度为150像素
        textField1.setPromptText("row..."); // 提示文本
        textField2.setPromptText("col...");
        Gridsize.getChildren().addAll(gridsize,textField1,gridsizeX,textField2);
        Gridsize.setAlignment(Pos.CENTER);
        Gridsize.setPadding(new Insets(10));
        // 创建 Tooltip
        Tooltip tooltipp = new Tooltip("Keep the rows and columns within 20.\nAfter all, your windows are limited.");
        gridsize.setOnMouseEntered(e -> tooltipp.show(gridsize, e.getScreenX(), e.getScreenY() + 10));
        gridsize.setOnMouseExited(e -> tooltipp.hide());

        HBox Gridshape = new HBox(20);
        Label gridshape = new Label("Grid Shape:");
        gridshape.getStyleClass().add("abel");
        Button sqButton = new Button("Square");
        Button hexButton = new Button("Hexagon");
        sqButton.getStyleClass().add("buttonsh");
        hexButton.getStyleClass().add("buttonsh");
        Gridshape.getChildren().addAll(gridshape,sqButton,hexButton);
        Gridshape.setAlignment(Pos.CENTER);
        Gridshape.setPadding(new Insets(10));
        sqButton.setOnAction(event -> {
            gridType = GridType.SQUARE;
            System.out.println(gridType);
        });
        hexButton.setOnAction(event -> {
            gridType = GridType.HEXAGON;
        });

        HBox Minenum = new HBox(20);
        Label minenum = new Label("Number of mines:");
        minenum.getStyleClass().add("label");
        TextField minesnumtext = new TextField();
//        minesnumtext.setPromptText(); // 提示文本
        // 创建 Tooltip
        Tooltip tooltip3 = new Tooltip("The number of bombs should be between 10% and 30% of the total count!");
        minenum.setOnMouseEntered(e -> tooltip3.show(minenum, e.getScreenX(), e.getScreenY() + 10));
        minenum.setOnMouseExited(e -> tooltip3.hide());

        minesnumtext.setPrefWidth(50); // 设置文本框的宽度为150像素
        Minenum.getChildren().addAll(minenum,minesnumtext);
        Minenum.setAlignment(Pos.CENTER);
        Minenum.setPadding(new Insets(10));


        Button startGameButton = new Button("START");
        startGameButton.setOnAction(event -> {
            String text1 = textField1.getText(); // 获取文本框中的文本
            String text2 = textField2.getText();
            String minenums = minesnumtext.getText(); // 获取文本框中的文本
            try {
                row = Integer.parseInt(text1); // 转换为整数
                System.out.println("row: " + row);
                col = Integer.parseInt(text2); // 转换为整数
                System.out.println("col: " + col);
                int minenumm = Integer.parseInt(minenums); // 转换为整数
                System.out.println("minenum: " + minenumm);
                int totalGrids = row * col;
                int minMines = (int)(totalGrids * 0.1);  // 最少 10% 的网格是炸弹
                int maxMines = (int)(totalGrids * 0.3);  // 最多 30% 的网格是炸弹
                if(row > 20 || col > 20){
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Number exceeded");
                    alert.setHeaderText(null);
                    alert.setContentText("Rows and columns must be kept within 20.");
                    // 设置 CSS 样式
                    DialogPane dialogPane = alert.getDialogPane();
                    dialogPane.setStyle("-fx-background-color: #333; " +
                            "-fx-text-fill: #FFF; " +
                            "-fx-border-color: #FF0000; " +
                            "-fx-border-width: 2px; " +
                            "-fx-padding: 10; " +
                            "-fx-font-size: 14px; " +
                            "-fx-font-family: 'Courier New';");
                    // 设置头部样式
                    Node header = dialogPane.lookup(".header-panel");
                    if (header != null) {
                        header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
                    }
                    // 设置内容样式
                    Node content = dialogPane.lookup(".content");
                    if (content != null) {
                        content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
                    }
                    // 修改按钮文本为 "Confirm"
                    ButtonType confirmButton = new ButtonType("Confirm");
                    alert.getButtonTypes().setAll(confirmButton);
//                    System.out.println("当前样式类: " + dialogPane.getStyleClass());
                    alert.showAndWait();
                }else if (minenumm < minMines || minenumm > maxMines) {
                    System.out.println("number of mine should be between " + minMines + " and " + maxMines + " ！");
                    // 弹出提示框提醒用户
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Invalid number of bombs");
                    alert.setHeaderText(null);
                    alert.setContentText("number of mine should be between " + minMines + " and " + maxMines + " ！");
                    // 设置 CSS 样式
                    DialogPane dialogPane = alert.getDialogPane();
                    dialogPane.setStyle("-fx-background-color: #333; " +
                            "-fx-text-fill: #FFF; " +
                            "-fx-border-color: #FF0000; " +
                            "-fx-border-width: 2px; " +
                            "-fx-padding: 10; " +
                            "-fx-font-size: 14px; " +
                            "-fx-font-family: 'Courier New';");
                    // 设置头部样式
                    Node header = dialogPane.lookup(".header-panel");
                    if (header != null) {
                        header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
                    }
                    // 设置内容样式
                    Node content = dialogPane.lookup(".content");
                    if (content != null) {
                        content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
                    }
                    // 修改按钮文本为 "Confirm"
                    ButtonType confirmButton = new ButtonType("Confirm");
                    alert.getButtonTypes().setAll(confirmButton);
//                    System.out.println("当前样式类: " + dialogPane.getStyleClass());
                    alert.showAndWait();
                }
                else if (gridType != null) {
                    GameFrame gameFrame = new GameFrame(row, col, minenumm, gridType);
                    gameFrame.initParentStage(primaryStage);
                    gameFrame.start(new Stage());
                } else {
                    System.out.println("Please select a grid type first!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number!"); // 处理异常
            }
        });

        centerlayout.getChildren().addAll(Gridsize,Gridshape,Minenum,startGameButton);
        return centerlayout;
    }
}
