package MineArithmetic;

import java.util.ArrayList;
import java.util.Random;

import Frame.GameFrame;
import MineBean.MineBean;
import MineBean.MineType;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Point2D;
import javafx.scene.control.Alert;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import Frame.GameFrame.Hexagon;

public class Arithmetic {
    private int MineCount;  // 雷子个数
    public int mRowNums;  // 格子行数
    public int mColumnNums;  // 格子列数
    public Pane pane2;

    private MineBean[][] beanArr;  // 雷子状态对应的数组
    public enum GridType {
        SQUARE,
        HEXAGON
    }

    private int unOpenGrids;  // 剩余未开启格子数量
    private int flagMines;  // 标记为雷子的个数

    private long gameStartTime;  // 游戏开始时间
    private boolean isGameOver = false;  // 游戏是否结束
    private boolean isPaused = false; //是否暂停
    private int remainingHints; // 剩余提示次数
    private GridType gridType; // 新增字段
    private Random random = new Random();

    private CallBack callBack; //回调
    public CallBack getCallBack() {
        return callBack;
    }

    public void setCallBack(CallBack callBack) {
        this.callBack = callBack;
    }

    public Arithmetic(int mineCount, int rowNums, int columnNums, CallBack callBack, GridType gridType) {
        if (mineCount <= 1 || rowNums <= 1 || columnNums <= 1) {
            return;
        }
        this.MineCount = mineCount;
        this.mRowNums = rowNums;
        this.mColumnNums = columnNums;
        this.callBack = callBack;
        this.remainingHints = 3; // 设置初始提示次数
        this.gridType = gridType; // 保存格子类型
//        this.gameFrame = gameFrame; // 初始化 GameFrame
        // 初始化
        reset();
    }

    public void reset() {
        resetOrCreateGrids(mRowNums, mColumnNums);
        makeRandomMines();
        initGridAroundStatus();
        unOpenGrids = beanArr.length * beanArr[0].length;
        flagMines = 0;
        gameStartTime = 0;
        this.remainingHints = 3; // 设置初始提示次数
        isGameOver = false;

        if (this.callBack != null) {
            this.callBack.onInit();
        }
    }

    // 初始化所有格子
    private void resetOrCreateGrids(int rowNums, int columnNums) {
        if (beanArr == null) {
            beanArr = new MineBean[rowNums][columnNums];
        }
        for (int i = 0; i < beanArr.length; i++) {
            for (int j = 0; j < beanArr[i].length; j++) {
                if (beanArr[i][j] == null) {
                    beanArr[i][j] = new MineBean(false, 0, MineType.MINE_STATUS_BLANK, i, j);
                }
                beanArr[i][j].reset();
            }
        }
    }


    // 初始化随机雷子
    private void makeRandomMines() {
        if (beanArr == null) {
            return;
        }
        int nowMines = 0;
        while (nowMines < MineCount) {
            int i = random.nextInt(beanArr.length);
            int j = random.nextInt(beanArr[0].length);
            MineBean mineBean = beanArr[i][j];
            if (!mineBean.isMineNow()) {
                mineBean.setMineNow();
                nowMines++;
            }
        }
    }

    // 计算格子周围雷子状态
    private void initGridAroundStatus() {
        if (beanArr == null) {
            return;
        }
        for (int i = 0; i < beanArr.length; i++) {
            for (int j = 0; j < beanArr[i].length; j++) {
                MineBean mineBean = beanArr[i][j];
                if (mineBean.isMineNow()) {
                    continue;
                }
                ArrayList<Point2D> list;
                if (gridType == GridType.HEXAGON) {
                    list = getHexagonAroundGrids(i, j);
                } else {
                    list = getAroundGrids(i, j); // 正方形的邻居计算
                }
                int mineCount = 0;
                for (Point2D tempPoint : list) {
                    MineBean tempBean = getMineBean((int) tempPoint.getX(), (int) tempPoint.getY());
                    if (tempBean != null && tempBean.isMineNow()) {
                        mineCount++;
                    }
                }
                mineBean.setMineCount(mineCount);
            }
        }
    }

    //square获取格子8个周围所有有效邻居格子数量
    private ArrayList<Point2D> getAroundGrids(int i, int j) {
        if (beanArr == null) {
            return null;
        }
        ArrayList<Point2D> aroundList = new ArrayList<>();
        aroundList.add(new Point2D(i - 1, j - 1));
        aroundList.add(new Point2D(i - 1, j));
        aroundList.add(new Point2D(i - 1, j + 1));
        aroundList.add(new Point2D(i, j - 1));
        aroundList.add(new Point2D(i, j + 1));
        aroundList.add(new Point2D(i + 1, j - 1));
        aroundList.add(new Point2D(i + 1, j));
        aroundList.add(new Point2D(i + 1, j + 1));
        aroundList.removeIf(point -> point.getX() < 0 || point.getY() < 0 || point.getX() >= beanArr.length || point.getY() >= beanArr[0].length);
        return aroundList;
    }

    //六边形逻辑
    private ArrayList<Point2D> getHexagonAroundGrids(int i, int j) {
        if (beanArr == null) {
            return null;
        }
        ArrayList<Point2D> aroundList = new ArrayList<>();
        aroundList.add(new Point2D(i - 1, j)); // 左
        aroundList.add(new Point2D(i + 1, j)); // 右
        aroundList.add(new Point2D(i, j - 1)); // 上
        aroundList.add(new Point2D(i, j + 1)); // 下
        aroundList.add(new Point2D(i - 1, j + 1)); // 右上
        aroundList.add(new Point2D(i + 1, j - 1)); // 左下
        aroundList.removeIf(point -> point.getX() < 0 || point.getY() < 0 || point.getX() >= beanArr.length || point.getY() >= beanArr[0].length);
        return aroundList;
    }

    // 添加提示功能
    public void hint() {
        if (remainingHints > 0) {
            ArrayList<MineBean> bombs = new ArrayList<>();
            for (int i = 0; i < mRowNums; i++) {
                for (int j = 0; j < mColumnNums; j++) {
                    MineBean mineBean = getMineBean(i, j);
                    if (mineBean != null && mineBean.isMineNow()) {
                        bombs.add(mineBean);
                    }
                }
            }
            if (!bombs.isEmpty()) {
                // 随机选择一个炸弹
                MineBean randomBomb = bombs.get(random.nextInt(bombs.size()));
                flashBomb(randomBomb);
                remainingHints--; // 减少提示次数
                callBack.onHintUsed(remainingHints); // 通知UI更新提示次数
            }
        }else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("提示");
            alert.setHeaderText(null);
            alert.setContentText("您已用完所有提示次数，无法继续使用提示按钮。");
            alert.showAndWait();
        }
    }

    // 闪烁炸弹格子的方法
    private void flashBomb(MineBean bomb) {
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.5), e -> {
            // 切换炸弹的显示状态
            if (bomb.getImageStatus() == MineType.MINE_STATUS_FLAG) {
                bomb.setImageStatus(MineType.MINE_STATUS_BLANK);
            } else {
                bomb.setImageStatus(MineType.MINE_STATUS_FLAG);
            }
            callBack.onRightClick(bomb, bomb.getRowIndex(), bomb.getColIndex()); // 更新UI
        }));

        timeline.setCycleCount(6); // 闪烁次数
        timeline.play();
    }

    public void leftClick(int i, int j) {
        if (beanArr == null || this.callBack == null || this.isGameOver) {
            return;
        }
        MineBean mineBean = getMineBean(i, j); //获取当前点击的格子
        if (mineBean == null || mineBean.isClickOpen()) { //如果格子空/已被点击，无需重复处理格子
            return;
        }
        mineBean.setClickOpen(true); //格子状态打开
//        System.out.println("Atihemetic：Left click on: (" + i + ", " + j);
        unOpenGrids--; //未打开格子数量减一

        if (mineBean.isMineNow()) { //格子是否是雷
            isGameOver = true;
            gameOver(i, j); //调用结束函数
            return;
        }

        if (gameStartTime <= 0) { //如果这是第一次点击，则记录游戏的时间
            gameStartTime = System.currentTimeMillis();
        }
        this.callBack.onLeftClick(mineBean, i, j);
        checkWin();
        if (mineBean.getMineCount() == MineType.MINE_STATUS_OPEN_0) { //如果当前格子的周围地雷数为0，则递归打开当前周围格子（空白区）
            recursionAround(i, j);
        }
    }

    private void recursionAround(int i, int j) {
        ArrayList<Point2D> list = getAroundGrids(i, j);
        for (Point2D tempPoint : list) {
            MineBean mineBean = getMineBean((int) tempPoint.getX(), (int) tempPoint.getY());
            if (mineBean != null && !mineBean.isMineNow() && !mineBean.isClickOpen()) {
                leftClick((int) tempPoint.getX(), (int) tempPoint.getY());
            }
        }
    }

    public void rightClick(int i, int j) {
        if (beanArr == null || this.callBack == null || this.isGameOver) {
            return;
        }
        MineBean mineBean = getMineBean(i, j);
        if (mineBean == null || mineBean.isClickOpen()) {
            return;
        }
        if (gameStartTime <= 0) {
            gameStartTime = System.currentTimeMillis();
        }
        if (flagMines < 0) {
            flagMines = 0;
        }
        switch (mineBean.getImageStatus()) {
            case MineType.MINE_STATUS_BLANK:
                mineBean.setImageStatus(MineType.MINE_STATUS_FLAG);
                flagMines++;
                break;
            case MineType.MINE_STATUS_FLAG:
                mineBean.setImageStatus(MineType.MINE_STATUS_UNKNOW);
                flagMines--;
                break;
            case MineType.MINE_STATUS_UNKNOW:
                mineBean.setImageStatus(MineType.MINE_STATUS_BLANK);
                break;
        }
        this.callBack.onRightClick(mineBean, i, j);
        System.out.println("sumflag:" + flagMines);
        checkWin();
    }

    public void drageFlag(int i, int j) {
        if (beanArr == null || this.callBack == null || this.isGameOver) {
            return;
        }
        MineBean mineBean = getMineBean(i, j);
        if (mineBean == null || mineBean.isClickOpen()) {
            return;
        }
        switch (mineBean.getImageStatus()) {
            case MineType.MINE_STATUS_BLANK:
                mineBean.setImageStatus(MineType.MINE_STATUS_FLAG);
                flagMines++;
                break;
            case MineType.MINE_STATUS_FLAG:
                mineBean.setImageStatus(MineType.MINE_STATUS_UNKNOW);
                flagMines--;
                break;
            case MineType.MINE_STATUS_UNKNOW:
                mineBean.setImageStatus(MineType.MINE_STATUS_BLANK);
                break;
        }
        this.callBack.onRightClick(mineBean, i, j);
        checkWin();
    }


    public void pause() {
        if (!isGameOver) {
            isPaused = true;
            if (this.callBack != null) {
                this.callBack.onPause();
            }
        }
    }

    public void resume() {
        if (isPaused) {
            isPaused = false;
            if (this.callBack != null) {
                this.callBack.onResume(); //恢复游戏
            }
        }
    }

    private void checkWin() {
        if (flagMines == MineCount) {
            isGameOver = true;
            this.callBack.onWin(System.currentTimeMillis() - gameStartTime);
        }
    }

    private void gameOver(int i, int j) {
        if (beanArr == null || this.callBack == null) {
            return;
        }
        MineBean mineBean = getMineBean(i, j);
        if (mineBean != null) {
            mineBean.setImageStatus(MineType.MINE_STATUS_MINE_CLICK);
            this.callBack.onRightClick(mineBean, i, j);
        }
        for (int k1 = 0; k1 < beanArr.length; k1++) {
            for (int k2 = 0; k2 < beanArr[k1].length; k2++) {
                mineBean = getMineBean(k1, k2);
                if (!mineBean.isClickOpen()) {
                    if (mineBean.isMineNow()) {
                        mineBean.setImageStatus(MineType.MINE_STATUS_OPEN_9);
                    } else {
                        mineBean.setImageStatus(mineBean.getMineCount());
                    }
                    this.callBack.onRightClick(mineBean, k1, k2);
                }
            }
        }
        this.callBack.onGameOver(System.currentTimeMillis() - gameStartTime);
    }

    public int getFlagMines() {
        return flagMines;
    }

    public int getRemainingMines() {
        return MineCount - flagMines; // 假设所有雷的数量是 MineCount
    }


    public MineBean getMineBean(int i, int j) {
        if (beanArr == null || i < 0 || i >= beanArr.length || j < 0 || j >= beanArr[0].length) {
            return null;
        }
        return beanArr[i][j];
    }

    public interface CallBack {
        void onInit();
        void onLeftClick(MineBean mineBean, int i, int j);
        void onRightClick(MineBean mineBean, int i, int j);
        void onWin(long time);
        void onGameOver(long time);// 失败
        void onPause();
        void onResume();
        void onHintUsed(int remainingHints); // 新增的回调方法
    }
}
