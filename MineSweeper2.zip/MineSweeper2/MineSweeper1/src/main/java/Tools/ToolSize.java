package Tools;

import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class ToolSize {
    // 获取屏幕宽高
    public static Rectangle2D getScreenSize() {
        return Screen.getPrimary().getBounds();
    }

    // 获取任务栏高度
    public static double getTaskbarHeight() {
        Rectangle2D fullScreenBounds = Screen.getPrimary().getBounds();   // 屏幕的完整尺寸
        Rectangle2D visualBounds = Screen.getPrimary().getVisualBounds(); // 可视区域，不包括任务栏
        return fullScreenBounds.getHeight() - visualBounds.getHeight();   // 任务栏高度 = 全部屏幕高度 - 可视区域高度
    }

    // 设置窗口图标
    public static void setStageIcon(Stage stage) {
        stage.getIcons().add(new Image("file:images/logo.png")); // 设置窗口图标，确保路径正确
    }
}
