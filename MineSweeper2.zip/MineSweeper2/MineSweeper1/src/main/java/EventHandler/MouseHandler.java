package EventHandler;

import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;

public class MouseHandler implements EventHandler<MouseEvent>{

    // 自定义左键点击处理
    public void mouseLeftClicked(MouseEvent event) {
        System.out.println("Left mouse button clicked");
        // 在这里实现你要执行的逻辑
    }

    // 自定义右键点击处理
    public void mouseRightClicked(MouseEvent event) {
        System.out.println("Right mouse button clicked");
        // 在这里实现你要执行的逻辑
    }

    // 处理鼠标按下事件
    public void mousePressed(MouseEvent event) {
        System.out.println("Mouse pressed");
    }

    // 处理鼠标释放事件
    public void mouseReleased(MouseEvent event) {
        System.out.println("Mouse released");
    }

    // 处理鼠标进入事件
    public void mouseEntered(MouseEvent event) {
        System.out.println("Mouse entered");
    }

    // 处理鼠标离开事件
    public void mouseExited(MouseEvent event) {
        System.out.println("Mouse exited");
    }

    // 实现 JavaFX 的 handle 方法，用于处理鼠标事件
    @Override
    public void handle(MouseEvent event) {
        // 区分左键和右键点击
        if (event.getButton() == MouseButton.PRIMARY) {
            mouseLeftClicked(event);
        } else if (event.getButton() == MouseButton.SECONDARY) {
            mouseRightClicked(event);
        }
    }
}
