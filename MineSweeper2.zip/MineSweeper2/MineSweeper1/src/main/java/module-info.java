module com.example.minesweeper1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.minesweeper1 to javafx.fxml;
    exports com.example.minesweeper1;
    exports Frame; // 导出包名为 Frame
}