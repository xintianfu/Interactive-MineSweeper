package Frame;

import MineArithmetic.Arithmetic;
import MineBean.MineImage;
import MineBean.MineType;
import javafx.animation.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Rectangle;
import javafx.scene.paint.Color;

import java.net.URL;

public class StartFrame extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("StartPage");
        BorderPane root = new BorderPane();
        // 创建黑色背景
        Rectangle blackBackground = new Rectangle(512, 512); // 设置黑色背景的大小
        blackBackground.setFill(Color.BLACK); // 设置填充颜色为黑色

        // 创建 ImageView 并设置背景图片
        ImageView background = new ImageView(new Image("file:///D:/IDEA/MineSweeper1/src/main/resources/images/1.jpg"));
        background.setFitWidth(512); // 设置宽度
        background.setFitHeight(512); // 设置高度
        background.setOpacity(0.5); // 设置透明度
        // 添加 GaussianBlur 效果以虚化边缘
        GaussianBlur blur = new GaussianBlur();
        blur.setRadius(5); // 设置虚化的半径
        background.setEffect(blur); // 将虚化效果应用到背景图片
        // 创建渐变动画
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(3000), background);
        fadeTransition.setFromValue(1.0); // 从不透明开始
        fadeTransition.setToValue(0.3); // 渐变到几乎透明
        fadeTransition.setCycleCount(FadeTransition.INDEFINITE); // 无限循环
        fadeTransition.setAutoReverse(true); // 自动反转
        // 创建旋转动画
        RotateTransition rotateTransition = new RotateTransition(Duration.millis(20000), background);
        rotateTransition.setFromAngle(0); // 从0度开始
        rotateTransition.setToAngle(360); // 旋转到360度
        rotateTransition.setCycleCount(RotateTransition.INDEFINITE); // 无限循环
        rotateTransition.setInterpolator(Interpolator.LINEAR); // 线性插值

// 创建缩放动画
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(3000), background);
        scaleTransition.setFromX(1.0); // 从正常大小开始
        scaleTransition.setToX(1.1); // 到1.1倍大小结束
        scaleTransition.setFromY(1.5); // 从正常大小开始
        scaleTransition.setToY(2); // 到1.1倍大小结束
        scaleTransition.setCycleCount(ScaleTransition.INDEFINITE); // 无限循环
        scaleTransition.setAutoReverse(true); // 自动反转

        // 开始播放动画
        fadeTransition.play();
        rotateTransition.play();
        scaleTransition.play();

        // 将背景 ImageView 添加到根节点
        root.getChildren().add(blackBackground); // 添加黑色背景
        root.getChildren().add(background);
        root.setTop(topLayout());
        root.setCenter(centerLayout(primaryStage));

        Scene scene1 = new Scene(root, 512, 512);
        URL url = getClass().getResource("/startframe.css");
        if (url != null) {
            scene1.getStylesheets().add(url.toExternalForm());
            System.out.println("found it!");
        } else {
            System.out.println("Resource not found: startframe.css");
        }

        primaryStage.setScene(scene1);
        primaryStage.show();

    }
    public HBox topLayout() {
        HBox pane = new HBox(10); //间距为10
        pane.setPadding(new Insets(15,12,15,12));
        pane.setAlignment(Pos.CENTER);
        pane.getStyleClass().add("top-pane"); // 添加背景颜色的样式
        // 创建logo并设置图像
        Label logo = new Label();
        setLabelImage(logo, MineType.MINE_LOGO);
//        logo.getStyleClass().add("logo"); //logo加css

        Label SelectionLabel = new Label("MineSweeperPLUS");
        SelectionLabel.getStyleClass().add("start-label");
        // 使用一个Region作为左边和右边的占位符
        Region leftSpacer = new Region();
//        leftSpacer.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        Region rightSpacer = new Region();
        leftSpacer.setPrefWidth(30); // 设置首选宽度
//        HBox.setHgrow(leftSpacer, Priority.ALWAYS); // 左侧占位符扩展
        HBox.setHgrow(rightSpacer, Priority.ALWAYS); // 右侧占位符扩展

        pane.getChildren().addAll(logo,leftSpacer,SelectionLabel,rightSpacer);

        // 给 leftBox 添加边框
//        pane.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        return pane;
    }

    public VBox centerLayout(Stage primaryStage){
        // 创建Image对象来表示鼠标光标的图片
        Image checkImage = new Image(getClass().getResource("/images/gif.gif").toExternalForm());
        Image checkingImage = new Image(getClass().getResource("/images/checking.png").toExternalForm());

        // 自定义鼠标指针
        ImageCursor checkCursor = new ImageCursor(checkImage, checkImage.getWidth() / 2, checkImage.getHeight() / 2);
        ImageCursor checkingCursor = new ImageCursor(checkingImage, checkingImage.getWidth() / 2, checkingImage.getHeight() / 2);

        VBox centerlayout = new VBox(45); //元素之间的上下
//        centerlayout.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
//        centerlayout.setPadding(new Insets(10));
        centerlayout.setAlignment(Pos.CENTER);
        // 在pane1和pane2上设置鼠标进入时默认的鼠标样式
        centerlayout.setOnMouseEntered(event -> {
            centerlayout.setCursor(checkCursor);
        });
        Button startButton = new Button("START");
        startButton.setOnAction(event -> {
            SelectionFrame selectionFrame = new SelectionFrame();  // Create an instance of SelectionFrame
            selectionFrame.start(new Stage());  // Start the SelectionFrame in the new Stage
            // 关闭当前 StartFrame 的 Stage (primaryStage)
            primaryStage.close();
        });

        // 鼠标按下时更改为checking.png
        startButton.setOnMousePressed(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                startButton.setCursor(checkingCursor); // 设置为checking.png
            }
        });

        // 鼠标松开时恢复为check.png
        startButton.setOnMouseReleased(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                startButton.setCursor(checkCursor); // 恢复为check.png
            }
        });


        centerlayout.getChildren().addAll(startButton);
        addShakeAnimation(startButton);
        return centerlayout;
    }
    public void setLabelImage(Label label, int flag) {
        if (label == null) {
            return;
        }
        ImageView icon = MineImage.getImageView(100, 100, flag);
        icon.setFitWidth(40); //长
        icon.setFitHeight(40); //宽
        label.setGraphic(icon);
    }
    private void addShakeAnimation(Button button) {

        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1);  // 从正常大小开始
        scaleTransition.setToX(1.1);   // 到1.1倍大小结束
        scaleTransition.setFromY(1);  // 从正常大小开始
        scaleTransition.setToY(1.1);   // 到1.1倍大小结束
        scaleTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环loop
        scaleTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        scaleTransition.setAutoReverse(true);


        // 鼠标悬停时同时开始动画start animation
        button.setOnMouseEntered(e -> {
            scaleTransition.play();
        });
        // 鼠标移出时停止动画stop animation
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1);     // 重置X轴缩放
            button.setScaleY(1);     // 重置Y轴缩放
        });
    }

}
