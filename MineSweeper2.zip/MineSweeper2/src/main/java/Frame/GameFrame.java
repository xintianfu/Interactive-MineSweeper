package Frame;

import MineArithmetic.Arithmetic;
import MineBean.MineType;
import MineBean.MineImage;
import Tools.ToolSize;
import javafx.animation.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseButton;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import MineBean.MineBean;
import javafx.util.Duration;
import MineArithmetic.Arithmetic.GridType;
import javafx.scene.shape.Polygon;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Alert.AlertType;



import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public class GameFrame extends Application {
    public final int MineCount; // 雷子个数Number of mines
    public final int mRowNums;   // 格子行数Number of grid rows
    public final int mColumnNums; // 格子列数Number of grid columns
    public final int mGridSideLength = 20; // 格子的边长The length of the side of the lattice
    private GridType gridType; // shape of grid

    private Label unOpenGridsLabel; //显示未打开的格子数Displays the number of unopened cells
    private int unOpenGrids; //未打开的格子数 the number of unopened cells
    private Tooltip unOpenMinesTooltip;
    private Button[][] buttonArr;
    private List<Hexagon> hexagons = new ArrayList<>();
    private Button resetBtn;
    private Label timerLabel;
    private Timeline timer;
    private long startTime;
    private long pausedTime;//暂停开始时间
    private boolean isClickComplete = true;
    private boolean gameStarted = false; //是否开始
    private boolean isPaused = false;
    private Label hintnum; // 声明为类的成员变量
    private final double HEXAGON_SIZE = 15;
    private double mWidth; //scene长
    private double mHeight; //scene宽
    private Pane pane2;
    private Timeline inactivityTimer; // 定义不活动计时器

    private Arithmetic gameUtils;
    private static String GAME_TITLE = "MineSweeper";
    private Stage parentStage;
    private Stage primaryStage;
    // 创建一个变量来跟踪是否已经点击
    final BooleanProperty clicked = new SimpleBooleanProperty(false);
    // 创建Image对象来表示鼠标光标的图片
    Image checkImage = new Image(getClass().getResource("/images/gif.gif").toExternalForm());
    Image checkingImage = new Image(getClass().getResource("/images/checking.png").toExternalForm());
    Image flagImage = new Image(getClass().getResource("/images/flag.gif").toExternalForm());

    // 自定义鼠标指针customize cursor
    ImageCursor checkCursor = new ImageCursor(checkImage, checkImage.getWidth() / 2, checkImage.getHeight() / 2);
    ImageCursor checkingCursor = new ImageCursor(checkingImage, checkingImage.getWidth() / 2, checkingImage.getHeight() / 2);
    ImageCursor flagCursor = new ImageCursor(flagImage, flagImage.getWidth() / 2, flagImage.getHeight() / 2);


    public GameFrame(int mRowNums, int mColumnNums, int mineCount,GridType gridType) {
        this.mRowNums = mRowNums;
        this.mColumnNums = mColumnNums;
        this.MineCount = mineCount;
        this.gridType = gridType; // 保存所选的格子类型
    }

    public void initParentStage(Stage parentStage) {
        this.parentStage = parentStage;
    }


    public static void main(String[] args) {
        System.out.println("we are starting……");
        launch(args);
        System.out.println("we are stopped!");
    }

    @Override
    public void start(Stage primaryStage) {

        if (parentStage != null) {
            parentStage.hide(); // 隐藏主页面Hide main page
        }
//        this.parentStage = primaryStage;//初始化
        // 初始化UI对应的背景数组状态Initializes the background array state corresponding to the UI
        gameUtils = new Arithmetic(MineCount, mRowNums, mColumnNums, callback, gridType);

        mWidth = mColumnNums * mGridSideLength;
        mHeight = mRowNums * mGridSideLength;

        primaryStage.setResizable(false);
        primaryStage.setTitle(GAME_TITLE);
        ToolSize.setStageIcon(primaryStage);

        BorderPane root = new BorderPane();
// 创建 ImageView 并设置背景图片
        ImageView background = new ImageView(new Image("file:///D:/IDEA/MineSweeper1/src/main/resources/images/1.jpg"));
        background.setFitWidth(1500); // 设置宽度
        background.setFitHeight(800); // 设置高度
        background.setOpacity(0.2); // 设置透明度

        // 创建渐变动画
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(3000), background);
        fadeTransition.setFromValue(1.0); // 从不透明开始
        fadeTransition.setToValue(0.1); // 渐变到几乎透明
        fadeTransition.setCycleCount(FadeTransition.INDEFINITE); // 无限循环
        fadeTransition.setAutoReverse(true); // 自动反转

        // 开始播放动画
        fadeTransition.play();

//         将背景 ImageView 添加到根节点
        root.getChildren().add(background);
        root.setTop(topLayout(primaryStage));
        root.setCenter(centerLayout());
        root.setBottom(bottomLayout());

//        Scene scene = new Scene(root, mWidth, mHeight);
//        System.out.println(mWidth);
        Scene scene = new Scene(root, 1500, 800);

        URL url = getClass().getResource("/gameframe.css");
        if (url != null) {
            scene.getStylesheets().add(url.toExternalForm());
            System.out.println("found it!");
        } else {
            System.out.println("Resource not found: gameframe.css");
        }

        // Initialize timer
        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> updateTimer()));
        timer.setCycleCount(Timeline.INDEFINITE);

        primaryStage.setScene(scene);
        primaryStage.sizeToScene();
        primaryStage.show();
    }

    public HBox topLayout(Stage primaryStage) { //顶上布局
        HBox pane = new HBox();
        pane.setPadding(new Insets(15,12,15,12));
        pane.getStyleClass().add("top-pane"); // 添加背景颜色的样式
        pane.setAlignment(Pos.CENTER);
        // 使用一个Region作为左边和右边的占位符Use a Region as a placeholder for the left and right sides
        Region leftSpacer = new Region();
//        leftSpacer.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        Region rightSpacer = new Region();
        leftSpacer.setPrefWidth(620);
        HBox.setHgrow(rightSpacer, Priority.ALWAYS);
        //左
        HBox leftBox = new HBox(10); //间距为10
        leftBox.setAlignment(Pos.CENTER);
        // 创建logo并设置图像Create the logo and set the image
        Label logo = new Label();
        setLabelImage(logo, MineType.MINE_LOGO);
        //剩余未开格子数
        unOpenGridsLabel = new Label();
        unOpenGrids = mRowNums * mColumnNums;
        unOpenGridsLabel.setText(String.valueOf(unOpenGrids));
        // 应用机械风格的 CSS
        unOpenGridsLabel.getStyleClass().add("mechanical-font");

        unOpenMinesTooltip = new Tooltip();
        Tooltip.install(unOpenGridsLabel,unOpenMinesTooltip);
        unOpenMinesTooltip.setText("Current number of unopened grid:" + unOpenGrids);
        unOpenGridsLabel.setOnMouseEntered(e -> unOpenMinesTooltip.show(unOpenGridsLabel, e.getScreenX(), e.getScreenY() + 10));
        unOpenGridsLabel.setOnMouseExited(e -> unOpenMinesTooltip.hide());


        leftBox.getChildren().addAll(logo, unOpenGridsLabel);

//        // 给 leftBox 添加边框
//        leftBox.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));

        //中：timer
        timerLabel = new Label("00:00");
        timerLabel.getStyleClass().add("mechanical-font");
//        BorderPane.setAlignment(timer, Pos.CENTER); // 确保计时器居中

//        timerLabel.setBorder(new Border(new BorderStroke(
//                Color.GREEN,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));

        //右pause,reset,menu
        HBox rightBox = new HBox(10);
        rightBox.setAlignment(Pos.CENTER);

        Button pauseBtn = new Button("pause");
        pauseBtn.getStyleClass().add("pause");
        pauseBtn.setOnAction(e -> {
            if (gameStarted && !isPaused) {
                isPaused = true; //设置暂停状态
//                timer.pause(); // 暂停计时器
                pausedTime = System.currentTimeMillis(); //记录暂停开始时间
                gameUtils.pause(); //触发暂停逻辑
                System.out.println("setpause没问题");
            }else if (!gameStarted){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("HINT");
                alert.setHeaderText(null);
                alert.setContentText("The game has not started yet!");
                // 设置 CSS 样式
                DialogPane dialogPane = alert.getDialogPane();
                dialogPane.setStyle("-fx-background-color: #333; " +
                        "-fx-text-fill: #FFF; " +
                        "-fx-border-color: #FF0000; " +
                        "-fx-border-width: 2px; " +
                        "-fx-padding: 10; " +
                        "-fx-font-size: 14px; " +
                        "-fx-font-family: 'Courier New';");
                // 设置头部样式
                Node header = dialogPane.lookup(".header-panel");
                if (header != null) {
                    header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
                }

                // 设置内容样式
                Node content = dialogPane.lookup(".content");
                if (content != null) {
                    content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
                }
                // 修改按钮文本为 "Confirm"
                ButtonType confirmButton = new ButtonType("Confirm");
                alert.getButtonTypes().setAll(confirmButton);
                // 获取按钮并修改样式
                Button confirmButtonNode = (Button) alert.getDialogPane().lookupButton(confirmButton);
                if (confirmButtonNode != null) {
                    confirmButtonNode.setStyle("-fx-background-color: #1C1C1C; " + // 按钮背景颜色
                            "-fx-text-fill: #FFFFFF; " + // 按钮文字颜色
                            "-fx-border-color: #444444; " + // 边框颜色
                            "-fx-border-width: 2px; " + // 边框宽度
                            "-fx-border-radius: 5px; " + // 边框圆角
                            "-fx-padding: 10; " + // 内边距
                            "-fx-font-size: 14px; " + // 字体大小
                            "-fx-font-family: 'Courier New'; " + // 字体类型
                            "-fx-background-radius: 5; " + // 圆角
                            "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1);"); // 阴影效果
                }
                // 显示弹窗并执行抖动动画
                alert.show();

                // 添加抖动效果
                shakeAlert(dialogPane);
            }
        });

        resetBtn = new Button();
        resetBtn.getStyleClass().add("reset");
        Tooltip tooltip2 = new Tooltip("restart");
        resetBtn.setOnMouseEntered(e -> tooltip2.show(resetBtn, e.getScreenX(), e.getScreenY() + 10));
        resetBtn.setOnMouseExited(e -> tooltip2.hide());
        setButtonImage(resetBtn, MineType.MINE_STATUS_MILE); //button上加笑脸图片
        resetBtn.setOnMousePressed(e -> {
            setButtonImage(resetBtn, MineType.MINE_STATUS_WAIT);
            timerLabel.setText("00:00"); // 重置计时器显示
            if (gridType ==GridType.SQUARE){
                gameUtils.reset(); // 重新初始化游戏
            }
            else{//六边形重置
                pane2.getChildren().clear();
                gameUtils.reset(); // 重新初始化游戏
                for (int row = 0; row < mRowNums; row++) {
                    for (int col = 0; col < mColumnNums; col++) {
                        Hexagon hexButton = new Hexagon(col, row);
                        setHexButtonImage(hexButton, MineType.MINE_STATUS_BLANK, pane2);
                        pane2.getChildren().add(hexButton);
                        final int ii = row;
                        final int jj = col;
                        hexButton.setOnMouseClicked(event -> {
                            switch (event.getButton()) {
                                case PRIMARY: leftClick(ii, jj); break;
                                case SECONDARY: rightClick(ii, jj); break;
                                default: break;
                            }
                        });
                        hexButton.setOnDragOver(event -> {
                            if (event.getGestureSource() != hexButton && event.getDragboard().hasString()) {
                                event.acceptTransferModes(TransferMode.COPY);
                            }
                            event.consume();
                        });
                        hexButton.setOnDragDropped(event -> {
                            Dragboard db = event.getDragboard();
                            boolean success = false;
                            if (db.hasString()) {
                                String content = db.getString();
                                if (content.equals("Flag")) {
                                    gameUtils.drageFlag(ii, jj);  // 调用 drageFlag 方法
                                    success = true;
                                }
                            }
                            event.setDropCompleted(success);
                            event.consume();
                        });
                    }
                }
            }
            unOpenGrids = mRowNums * mColumnNums ;
            unOpenGridsLabel.setText(String.valueOf(unOpenGrids));
            isClickComplete = true; // 允许点击
            gameStarted = false; // 游戏未开始
        }); //鼠标按下变wait图片
        resetBtn.setOnMouseReleased(e -> setButtonImage(resetBtn, MineType.MINE_STATUS_MILE)); //释放变笑脸

        ComboBox<String> menuBox = new ComboBox<>();
        menuBox.getItems().addAll("Easy","Medium","Advanced","Customize");
        menuBox.setStyle("-fx-background-color: #1C1C1C; " + // 深色背景
                "-fx-text-fill: #FFF; " + // 白色文本
                "-fx-pref-width: 75px; " + // 设置固定宽度
                "-fx-pref-height: 40px; " + // 设置固定高度
                "-fx-font-family: Courier New; " + // 字体样式
                "-fx-border-color: #444444; " + // 边框颜色
                "-fx-border-width: 2px; " + // 边框宽度
                "-fx-border-radius: 5px; " + // 边框圆角
                "-fx-font-size: 14px; " + // 字体大小
                "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1); " + // 阴影效果
                "-fx-background-radius: 5; " + // 背景圆角
                "-fx-padding: 5px;"); // 内边距
        menuBox.getStyleClass().add("combo-box"); // 添加样式类

        menuBox.setOnAction(event -> {
            String selectedOption = menuBox.getValue();
            // 暂停计时器
            if (gameStarted && !isPaused) {
                isPaused = true;  // 设置为暂停状态
                pausedTime = System.currentTimeMillis();  // 记录暂停开始时间
//                gameUtils.pause();  // 触发暂停逻辑
                System.out.println("menubox计时器已暂停!");
            }

            // 创建确认弹框
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirm to start a new game");
            alert.setHeaderText(null);
            alert.setContentText("Do you want to start a new game??");
            // 设置 CSS 样式
            DialogPane dialogPane = alert.getDialogPane();
            dialogPane.setStyle("-fx-background-color: #333; " +
                    "-fx-text-fill: #FFF; " +
                    "-fx-border-color: #FF0000; " +
                    "-fx-border-width: 2px; " +
                    "-fx-padding: 10; " +
                    "-fx-font-size: 14px; " +
                    "-fx-font-family: 'Courier New';");
            // 设置头部样式
            Node header = dialogPane.lookup(".header-panel");
            if (header != null) {
                header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
            }
            // 设置内容样式
            Node content = dialogPane.lookup(".content");
            if (content != null) {
                content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
            }
            shakeAlert(dialogPane);
            // 创建自定义按钮
            ButtonType yesButton = new ButtonType("YES", ButtonBar.ButtonData.YES);
            ButtonType noButton = new ButtonType("NO", ButtonBar.ButtonData.NO);
            alert.getButtonTypes().setAll(yesButton, noButton);
            // 获取按钮并修改样式
            Button yesButtonNode = (Button) alert.getDialogPane().lookupButton(yesButton);
            if (yesButtonNode != null) {
                yesButtonNode.setStyle("-fx-background-color: #1C1C1C; " + // 按钮背景颜色
                        "-fx-text-fill: #FFFFFF; " + // 按钮文字颜色
                        "-fx-border-color: #444444; " + // 边框颜色
                        "-fx-border-width: 2px; " + // 边框宽度
                        "-fx-border-radius: 5px; " + // 边框圆角
                        "-fx-padding: 10; " + // 内边距
                        "-fx-font-size: 14px; " + // 字体大小
                        "-fx-font-family: 'Courier New'; " + // 字体类型
                        "-fx-background-radius: 5; " + // 圆角
                        "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1);"); // 阴影效果
            }
            Button noButtonNode = (Button) alert.getDialogPane().lookupButton(noButton);
            if (noButtonNode != null) {
                noButtonNode.setStyle("-fx-background-color: #FFFFFF; " + // 按钮背景颜色
                        "-fx-text-fill: #1C1C1C; " + // 按钮文字颜色
                        "-fx-border-color: #444444; " + // 边框颜色
                        "-fx-border-width: 2px; " + // 边框宽度
                        "-fx-border-radius: 5px; " + // 边框圆角
                        "-fx-padding: 10; " + // 内边距
                        "-fx-font-size: 14px; " + // 字体大小
                        "-fx-font-family: 'Courier New'; " + // 字体类型
                        "-fx-background-radius: 5; " + // 圆角
                        "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1);"); // 阴影效果
            }

            Optional<ButtonType> result = alert.showAndWait();
                // 处理用户选择
            if (result.isPresent() && result.get() == yesButton) { // 如果用户点击了"是"
                GameFrame gameFramenew = null;
                gameStarted = false; // 游戏未开始
                switch (selectedOption) {
                    case "Easy":
                        gameFramenew = new GameFrame(10, 10, 10, GridType.SQUARE);
                        break;
                    case "Medium":
                        gameFramenew = new GameFrame(20, 20, 40, GridType.SQUARE);
                        break;
                    case "Advanced":
                        gameFramenew = new GameFrame(20, 20, 40, GridType.HEXAGON);
                        break;
                    case "Customize":
                        CustomizeFrame customizeFrame = new CustomizeFrame();
                        customizeFrame.start(new Stage());
                        primaryStage.close();
                        break;
                    default:
                        return;
                }

                if (gameFramenew != null) {
                    gameFramenew.initParentStage(primaryStage); // 传入主窗口
                    gameFramenew.start(new Stage()); // 启动新窗口
                }
            } else {
                // 用户点击了"否"或关闭了对话框，恢复计时器
                if (isPaused) {
                    isPaused = false;
                    long pauseDuration = System.currentTimeMillis() - pausedTime; //暂停时间
                    startTime += pauseDuration; //更新开始时间，排除暂停时间
                    gameUtils.resume(); //触发恢复逻辑
                    timer.play(); //计时器恢复
                    System.out.println("resume没问题");
                }
            }
        });

        rightBox.getChildren().addAll(pauseBtn, resetBtn, menuBox);
//        rightBox.setBorder(new Border(new BorderStroke(
//                Color.YELLOW,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        pane.getChildren().addAll(leftBox,leftSpacer,timerLabel,rightSpacer,rightBox);
        return pane;
    }

    // 添加抖动效果的方法
    private void shakeAlert(Node alertContent) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(500), alertContent);
        scaleTransition.setFromX(1);
        scaleTransition.setFromY(1);
        scaleTransition.setToX(1.05); // 放大
        scaleTransition.setToY(1.05); // 放大
        scaleTransition.setCycleCount(6); // 设置抖动的次数
        scaleTransition.setAutoReverse(true); // 启用自动反转
        scaleTransition.play();
    }

    public Pane centerLayout() {  //中间布局

        //square pane
        GridPane pane1 = new GridPane();
        pane1.setPadding(new Insets(15,12,15,12));

//        pane1.setBorder(new Border(new BorderStroke(
//                Color.GREEN,                    // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径（null 代表没有圆角）
//                new BorderWidths(2)             // 边框宽度
//        )));

        pane1.setAlignment(Pos.CENTER);
        pane1.setGridLinesVisible(true); //显示网格线
        if (buttonArr == null) {
            buttonArr = new Button[mRowNums][mColumnNums]; //初始化创建二维数组
        }

        //hex pane
        pane2 = new Pane();
        pane2.setPadding(new Insets(15,12,15,12));

//        pane2.setBorder(new Border(new BorderStroke(
//                Color.RED,                    // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径（null 代表没有圆角）
//                new BorderWidths(2)             // 边框宽度
//        )));
        // 计算居中位置
        double totalWidth = mColumnNums * (1.5 * HEXAGON_SIZE);
        double totalHeight = mRowNums * (Math.sqrt(3*1.5) * HEXAGON_SIZE);
        double offsetX = (1500 - totalWidth) / 2; // 假设窗口宽度为 1500
        double offsetY = (800 - totalHeight) / 2; // 假设窗口高度为 800

        pane2.setTranslateX(offsetX);
        pane2.setTranslateY(offsetY);

        // 创建一个 StackPane 作为容器
        StackPane stackPane = new StackPane();
        stackPane.setAlignment(Pos.CENTER); // 设置对齐方式为中心

        // 在pane1和pane2上设置鼠标进入时默认的鼠标样式
        stackPane.setOnMouseEntered(event -> {
            stackPane.setCursor(checkCursor);
        });


        //超时提醒
        inactivityTimer = new Timeline(new KeyFrame(Duration.millis(20000), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("clicked: " + clicked.get() + ", gameStarted: " + gameStarted);
                if (!clicked.get() && gameStarted ) { // 检查是否有用户点击
                    System.out.println("Inactivity detected, showing alert...");
                    showInactivityAlert(); // 弹出提醒
                }
                // 在这里重置 clicked 状态，以防止连续弹出警报Reset the clicked state to prevent continuous pop-up alerts
                clicked.set(false); // 重置为 false，准备下一次检测
            }
        }));
        inactivityTimer.setCycleCount(Timeline.INDEFINITE); // 只运行一次
        inactivityTimer.play(); // 启动计时器


        if (gridType == GridType.SQUARE) {//Generate a square grid
            for (int i = 0; i < mRowNums; i++) {
                for (int j = 0; j < mColumnNums; j++) {
                    System.out.println("Adding button at: " + i + ", " + j);
                    //1
                    Button button = new Button();
                    buttonArr[i][j] = button;  // 继续初始化二维数组
                    setButtonImage(button, MineType.MINE_STATUS_BLANK); // 按钮设置空图片

                    setButtonImage(button, MineType.MINE_STATUS_BLANK); //按钮设置空图片

                    // 抖动动画
                    ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
                    scaleTransition.setFromX(1);  // 从正常大小开始
                    scaleTransition.setToX(1.1);   // 到1.1倍大小结束
                    scaleTransition.setFromY(1);  // 从正常大小开始
                    scaleTransition.setToY(1.1);   // 到1.1倍大小结束
                    scaleTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环
                    scaleTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
                    scaleTransition.setAutoReverse(true);

                    button.setOnMouseEntered(event -> scaleTransition.playFromStart());
                    // 鼠标离开时停止动画并重置位置
                    button.setOnMouseExited(event -> {
                        scaleTransition.stop(); // 停止动画
                        button.setTranslateX(0); // 重置位置
                    });
                    // 鼠标按下时更改为checking.png
                    button.setOnMousePressed(event -> {
                        if (event.getButton() == MouseButton.PRIMARY) {
                            stackPane.setCursor(checkingCursor); // 设置为checking.png
                        }
                    });
                    button.setOnMousePressed(event -> {
                        if (event.getButton() == MouseButton.SECONDARY) {
                            stackPane.setCursor(flagCursor); // 设置为checking.png
                        }
                    });

                    // 鼠标松开时恢复为check.png
                    button.setOnMouseReleased(event -> {
//                        if (event.getButton() == MouseButton.PRIMARY) {
                            stackPane.setCursor(checkCursor); // 恢复为check.png
//                        }
                    });

                    final int ii = i;
                    final int jj = j;


                    button.setOnMouseClicked(event -> {
                        clicked.set(true); // 标记为已点击
                        scaleTransition.stop();  // 停止抖动动画
                        button.setTranslateX(0); // 重置位移
                        resetInactivityTimer(); // 重置活动计时器
                        switch (event.getButton()) { //根据鼠标左右按钮调用对应的函数
                            case PRIMARY:
                                leftClick(ii, jj);
                                break;
                            case SECONDARY:
                                rightClick(ii, jj);
                                break;
                            default:
                                break;
                        }
                    });


                    // 添加拖拽放置事件drag event
                    button.setOnDragOver(event -> {
                        stackPane.setCursor(flagCursor);
//                        if (event.getGestureSource() != buttonArr[ii][jj] &&
                        if (event.getGestureSource() != button && event.getDragboard().hasString()) {
                            event.acceptTransferModes(TransferMode.COPY);
                        }
                        event.consume();
                    });

                    button.setOnDragDropped(event -> {
                        Dragboard db = event.getDragboard();
                        boolean success = false;
                        if (db.hasString()) {  // 不需要传入参数
                            String content = db.getString(); // 获取剪贴板中的字符串内容
                            if (content.equals("Flag")) {  // 检查内容是否为 "Flag"
                                gameUtils.drageFlag(ii, jj); // 调用 drageFlag 方法
                                success = true;
                            }
                        }
                        event.setDropCompleted(success);
                        event.consume();
                    });

                    pane1.add(button, j, i);
                }

            }
            stackPane.getChildren().add(pane1); // 将 pane1 添加到 StackPane
        }else{
            // 生成六边形网格Generate a hexagonal grid
            for (int row = 0; row < mRowNums; row++) {
                for (int col = 0; col < mColumnNums; col++) {
                    Hexagon hexButton = new Hexagon(col, row);
                    setHexButtonImage(hexButton, MineType.MINE_STATUS_BLANK, pane2);
                    pane2.getChildren().add(hexButton);

                    final int ii = row;
                    final int jj = col;
                    // 抖动动画
                    ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), hexButton);
                    scaleTransition.setFromX(1);  // 从正常大小开始
                    scaleTransition.setToX(1.1);   // 到1.1倍大小结束
                    scaleTransition.setFromY(1);  // 从正常大小开始
                    scaleTransition.setToY(1.1);   // 到1.1倍大小结束
                    scaleTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环
                    scaleTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
                    scaleTransition.setAutoReverse(true);

//                    buttonArr[i][j].setOnMouseEntered(event -> shakeAnimation.playFromStart()); // 鼠标进入时开始抖动
                    hexButton.setOnMouseEntered(event -> scaleTransition.playFromStart());
                    // 鼠标离开时停止动画并重置位置
                    hexButton.setOnMouseExited(event -> {
                        scaleTransition.stop(); // 停止动画
                        hexButton.setTranslateX(0); // 重置位置
                    });

                    // 鼠标按下时切换图标
                    hexButton.setOnMousePressed(event -> {
                        if (event.getButton() == MouseButton.PRIMARY) {
                            stackPane.setCursor(checkingCursor);
                        }
                    });
                    hexButton.setOnMousePressed(event -> {
                        if (event.getButton() == MouseButton.SECONDARY) {
                            stackPane.setCursor(flagCursor); // 设置为checking.png
                        }
                    });

                    // 鼠标松开时恢复图标
                    hexButton.setOnMouseReleased(event -> {
//                        if (event.getButton() == MouseButton.PRIMARY) {
                            stackPane.setCursor(checkCursor);
//                        }
                    });

                    hexButton.setOnMouseClicked(event -> {
                        clicked.set(true); // 标记为已点击
                        scaleTransition.stop();  // 停止抖动动画
                        hexButton.setTranslateX(0); // 重置位移
                        resetInactivityTimer(); // 重置活动计时器
                        switch (event.getButton()) {
                            case PRIMARY: leftClick(ii, jj); break;
                            case SECONDARY: rightClick(ii, jj); break;
                            default: break;
                        }
                    });

                    // 添加拖拽放置事件
                    hexButton.setOnDragOver(event -> {
                        if (event.getGestureSource() != hexButton && event.getDragboard().hasString()) {
                            event.acceptTransferModes(TransferMode.COPY);
                        }
                        event.consume();
                    });

                    hexButton.setOnDragDropped(event -> {
                        Dragboard db = event.getDragboard();
                        boolean success = false;
                        if (db.hasString()) {
                            String content = db.getString();
                            if (content.equals("Flag")) {
                                gameUtils.drageFlag(ii, jj);  // 调用 drageFlag 方法
                                success = true;
                            }
                        }
                        event.setDropCompleted(success);
                        event.consume();
                    });
                }
            }
            stackPane.setAlignment(Pos.CENTER);
            stackPane.getChildren().add(pane2); // 将 pane2 添加到 StackPane
        }
        return stackPane;
    }

    // 设置光标的方法
    private void setCustomCursor(Pane pane, Cursor cursor) {
        pane.setCursor(cursor);
    }

    public void showInactivityAlert() {//The timeout window is displayed
        System.out.println("超时了！！!");
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Inactivity Alert");
            alert.setHeaderText(null);
            alert.setContentText("Having trouble? Hurry up!!!");
            // 设置 CSS 样式
            DialogPane dialogPane = alert.getDialogPane();
            dialogPane.setStyle("-fx-background-color: #333; " +
                    "-fx-text-fill: #FFF; " +
                    "-fx-border-color: #FF0000; " +
                    "-fx-border-width: 2px; " +
                    "-fx-padding: 10; " +
                    "-fx-font-size: 14px; " +
                    "-fx-font-family: 'Courier New';");
            // 设置头部样式
            Node header = dialogPane.lookup(".header-panel");
            if (header != null) {
                header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
            }
            // 设置内容样式
            Node content = dialogPane.lookup(".content");
            if (content != null) {
                content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
            }
            shakeAlert(dialogPane);

            ButtonType confirmButton = new ButtonType("Confirm");
            alert.getButtonTypes().setAll(confirmButton);
            // 获取按钮并修改样式
            Button confirmButtonNode = (Button) alert.getDialogPane().lookupButton(confirmButton);
            if (confirmButtonNode != null) {
                confirmButtonNode.setStyle("-fx-background-color: #1C1C1C; " + // 按钮背景颜色
                        "-fx-text-fill: #FFFFFF; " + // 按钮文字颜色
                        "-fx-border-color: #444444; " + // 边框颜色
                        "-fx-border-width: 2px; " + // 边框宽度
                        "-fx-border-radius: 5px; " + // 边框圆角
                        "-fx-padding: 10; " + // 内边距
                        "-fx-font-size: 14px; " + // 字体大小
                        "-fx-font-family: 'Courier New'; " + // 字体类型
                        "-fx-background-radius: 5; " + // 圆角
                        "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1);"); // 阴影效果
            }
            alert.showAndWait();
        });
    }
    // 重置不活动计时器Reset the inactive timer
    private void resetInactivityTimer() {
//        clicked.set(false); // 假设我们在点击后立即设为 false

        // 可以选择在这里重置 inactivityTimer 的状态
        inactivityTimer.playFromStart();
    }


    public class Hexagon extends Polygon {
        private boolean opened = false;
        private int col; // 列索引
        private int row; // 行索引
        private double x = 0; //具体坐标
        private double y = 0;

        public Hexagon(int col, int row) {
            this.col = col;
            this.row = row;

            x = col * (1.5 * HEXAGON_SIZE);
            y = row * (Math.sqrt(3) * HEXAGON_SIZE);
            if (col % 2 != 0) {
                y += (Math.sqrt(3) / 2) * HEXAGON_SIZE;
            }
//            System.out.println("Hexagon Position: (" + x + ", " + y + ")");
            createHexagonShape();
            setStroke(Color.LIGHTBLUE);
            setStrokeWidth(2);  // 设置边的粗细，2 是一个较粗的宽度，按需调整
            setFill(Color.TRANSPARENT);  // 设置为透明填充以便显示背景图片
        }

        public double getX() {
            return x;
        }

        public double getY() {
            return y;
        }

        private void createHexagonShape() {
            //Polygon hex = new Polygon();
            for (int i = 0; i < 6; i++) {
                double angle = Math.toRadians(60 * i);
                this.getPoints().addAll(
                        15 * Math.cos(angle) + this.x,
                        15 * Math.sin(angle) + this.y
                );
            }
        }

    }


    public HBox bottomLayout(){
        HBox pane = new HBox();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(15,12,15,12));
        pane.getStyleClass().add("top-pane"); // 添加背景颜色的样式
//        pane.setBorder(new Border(new BorderStroke(
//                Color.GREEN,                    // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径（null 代表没有圆角）
//                new BorderWidths(2)             // 边框宽度
//        )));
        pane.setSpacing(100);

        //hint组件
        HBox hintpane = new HBox();
        hintpane.setAlignment(Pos.CENTER);
//        hintpane.setStyle("-fx-border-color:BLACK");
        hintpane.setSpacing(30);
        Button hintBtn = new Button("hint");
        hintBtn.getStyleClass().add("hintbtn"); // 添加样式
//        hintBtn.setPrefSize(100,20);
        hintBtn.setOnAction(event -> {
            gameUtils.hint();// 调用 hint 方法
        });
        hintnum = new Label("3"); // 初始化 hintnum
        Tooltip tooltip = new Tooltip("Remaining hint count");
        hintnum.setOnMouseEntered(e -> tooltip.show(hintnum, e.getScreenX(), e.getScreenY() + 10));
        hintnum.setOnMouseExited(e -> tooltip.hide());
        hintnum.getStyleClass().add("mechanical-font"); // 添加样式
        hintnum.setPrefSize(20,20);
        hintpane.getChildren().addAll(hintBtn,hintnum);

        Label Flag = new Label("Flag");
        Flag.setPrefSize(100,20);
        Flag.setStyle("-fx-border-color:BLACK");
        Flag.getStyleClass().add("flaglabel"); // 添加样式
        Flag.setAlignment(Pos.CENTER);
        // 创建 Tooltip
        Tooltip tooltip1 = new Tooltip("Drag the flag onto the square you want to mark");
        Flag.setOnMouseEntered(e -> tooltip1.show(Flag, e.getScreenX(), e.getScreenY() + 10));
        Flag.setOnMouseExited(e -> tooltip1.hide());

        // 设置拖拽事件
        Flag.setOnDragDetected(event -> {
            // 改变光标样式为手形
            pane.setCursor(flagCursor); // 改变光标为手形
            Dragboard db = Flag.startDragAndDrop(TransferMode.ANY);
            ClipboardContent content = new ClipboardContent();
            content.putString("Flag");
            db.setContent(content);
            event.consume();
        });
        // 恢复光标样式Restore cursor style
        Flag.setOnDragDone(event -> {
            pane.setCursor(checkCursor); // 恢复光标为默认样式
        });

        pane.getChildren().addAll(Flag,hintpane);
        return pane;
    }


    public void leftClick(int i, int j) {
        System.out.println("leftClick: " + i + ", " + j);
        if (gameUtils == null || !isClickComplete) {
            return;
        }
        if (!gameStarted) {
            // Start the game and timer
            startTime = System.currentTimeMillis();
            timer.play();
            gameStarted = true;
        }
        isClickComplete = false; //点击正在进行，防止同时多次点击
        gameUtils.leftClick(i, j); //调用Arithmetic的leftClick函数
        updateUnopenedGrids();
        isClickComplete = true; //点击操作完成
    }

    public void rightClick(int i, int j) {
        if (gameUtils == null) {
            return;
        }
        gameUtils.rightClick(i, j);
    }

    public void setButtonImage(Button button, int flag) {
        if (button == null) {
            return;
        }
        ImageView icon = MineImage.getImageView(mGridSideLength, mGridSideLength, flag);
        button.setGraphic(icon);
    }

    public void setHexButtonImage(Hexagon hexButton, int flag, Pane pane) {
        if (hexButton == null) {
            return;
        }
        ImageView icon = MineImage.getImageView(mGridSideLength, mGridSideLength, flag);
        // 获取图片的宽高，计算中心点偏移量
        double iconWidth = icon.getFitWidth();
        double iconHeight = icon.getFitHeight();
        // 计算六边形的中心位置
        double hexX = hexButton.getX();
        double hexY = hexButton.getY();
        System.out.println("setHexButtonImage: (" + hexButton.row + ", " + hexButton.col + ") with flag: " + flag);
        System.out.println(hexX);
        System.out.println(hexY);
        // 将图片居中于六边形
        icon.setTranslateX(-iconWidth / 2 + hexX);  // 偏移X轴，使图片居中
        icon.setTranslateY(-iconHeight / 2 + hexY); // 偏移Y轴，使图片居中
        pane.getChildren().add(icon);  // 将图像添加到 hexButton 中
        icon.setOpacity(1);
    }


    public void setLabelImage(Label label, int flag) {
        if (label == null) {
            return;
        }
        ImageView icon = MineImage.getImageView(100, 100, flag);
        icon.setFitWidth(40); //长
        icon.setFitHeight(40); //宽
        label.setGraphic(icon);
    }

    public void updateUnopenedGrids() {
        int remainingUnopened = 0;
        for (int i = 0; i < mRowNums; i++) {
            for (int j = 0; j < mColumnNums; j++) {
                if (!gameUtils.getMineBean(i, j).isClickOpen()) {
                    remainingUnopened++;
                }
            }
        }
        unOpenGrids = remainingUnopened;
        unOpenGridsLabel.setText(String.valueOf(unOpenGrids));
        // 更新 Tooltip 的文本
        if (unOpenMinesTooltip != null) {
            unOpenMinesTooltip.setText("Current number of unopened squares:" + unOpenGrids);
        }
        System.out.println(unOpenGrids);
    }

    private Arithmetic.CallBack callback = new Arithmetic.CallBack() {

        @Override
        public void onWin(long time) {
            setButtonImage(resetBtn, MineType.MINE_STATUS_WIN);
            timer.stop();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("YOU WIN!!!");
            alert.setHeaderText(null);
            alert.setContentText("WIN! Time Taken:" + time / 1000 + " s");
            // 设置 CSS 样式
            DialogPane dialogPane = alert.getDialogPane();
            dialogPane.setStyle("-fx-background-color: #333; " +
                    "-fx-text-fill: #FFF; " +
                    "-fx-border-color: #FF0000; " +
                    "-fx-border-width: 2px; " +
                    "-fx-padding: 10; " +
                    "-fx-font-size: 14px; " +
                    "-fx-font-family: 'Courier New';");
            // 设置头部样式
            Node header = dialogPane.lookup(".header-panel");
            if (header != null) {
                header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
            }
            // 设置内容样式
            Node content = dialogPane.lookup(".content");
            if (content != null) {
                content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
            }
            shakeAlert(dialogPane);
            alert.showAndWait();
        }

        @Override
        public void onInit() {
            initButtons();
        }

        public void onPause() {
//            isPaused = true;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("PAUSE");
            alert.setHeaderText(null);
            alert.setContentText("The game is paused!!! Click the continue button to resume the game.");
            System.out.println("onPause调用");
            // 设置 CSS 样式
            DialogPane dialogPane = alert.getDialogPane();
            dialogPane.setStyle("-fx-background-color: #333; " +
                    "-fx-text-fill: #FFF; " +
                    "-fx-border-color: #FF0000; " +
                    "-fx-border-width: 2px; " +
                    "-fx-padding: 10; " +
                    "-fx-font-size: 14px; " +
                    "-fx-font-family: 'Courier New';");
            // 设置头部样式
            Node header = dialogPane.lookup(".header-panel");
            if (header != null) {
                header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
            }
            // 设置内容样式
            Node content = dialogPane.lookup(".content");
            if (content != null) {
                content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
            }
            shakeAlert(dialogPane);
            ButtonType resumeButton = new ButtonType("CONTINUE");
            alert.getButtonTypes().setAll(resumeButton);
            // 获取按钮并修改样式
            Button yesButtonNode = (Button) alert.getDialogPane().lookupButton(resumeButton);
            if (yesButtonNode != null) {
                yesButtonNode.setStyle("-fx-background-color: #1C1C1C; " + // 按钮背景颜色
                        "-fx-text-fill: #FFFFFF; " + // 按钮文字颜色
                        "-fx-border-color: #444444; " + // 边框颜色
                        "-fx-border-width: 2px; " + // 边框宽度
                        "-fx-border-radius: 5px; " + // 边框圆角
                        "-fx-padding: 10; " + // 内边距
                        "-fx-font-size: 14px; " + // 字体大小
                        "-fx-font-family: 'Courier New'; " + // 字体类型
                        "-fx-background-radius: 5; " + // 圆角
                        "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1);"); // 阴影效果
            }
            alert.showAndWait().ifPresent(response -> {  //带有阻塞效果的 Alert 弹框
                // 处理用户点击的按钮
                if (response.equals(resumeButton)) {
//                    isPaused = false; //恢复游戏状态
                    long pauseDuration = System.currentTimeMillis() - pausedTime; //暂停时间
                    startTime += pauseDuration; //更新开始时间，排除暂停时间
                    gameUtils.resume(); //触发恢复逻辑
                    timer.play(); //计时器恢复
                    System.out.println("resume没问题");
                }
            });
        }

        @Override
        public void onResume() {
            isPaused = false;
            System.out.println("onResume() 方法被调用");
        }

        @Override
        public void onHintUsed(int remainingHints) {
            // 实现逻辑，更新提示数量显示等
            hintnum.setText(String.valueOf(remainingHints)); // 更新剩余提示次数
            System.out.println("Remaining hints: " + remainingHints);
        }

        @Override
        public void onGameOver(long time) {
            setButtonImage(resetBtn, MineType.MINE_STATUS_DEAD);
            timer.stop();
            // 获取剩余未标记的炸弹数量和已标记的炸弹数量
            int remainingMines = gameUtils.getRemainingMines(); // 调用 Arithmetic 中的方法
            int flaggedMines = gameUtils.getFlagMines(); // 调用 Arithmetic 中的方法
            // 打印调试信息
            System.out.println("Time taken:" + (time / 1000.0));
            System.out.println("Number of unmarked bombs remaining:" + remainingMines);
            System.out.println("Number of bombs already marked:" + flaggedMines);

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("GAME OVER");
            alert.setHeaderText(null);
//            alert.setContentText("好像是输了?!");
            // 设置内容
            String content = String.format("It seems like you lost?!\nTime taken: %.2f s\nNumber of unmarked bombs remaining: %d\nNumber of bombs already marked: %d",
                    time / 1000.0, remainingMines, flaggedMines);
            alert.setContentText(content);
            // 设置 CSS 样式
            DialogPane dialogPane = alert.getDialogPane();
            dialogPane.setStyle("-fx-background-color: #333; " +
                    "-fx-text-fill: #FFF; " +
                    "-fx-border-color: #FF0000; " +
                    "-fx-border-width: 2px; " +
                    "-fx-padding: 10; " +
                    "-fx-font-size: 14px; " +
                    "-fx-font-family: 'Courier New';");
            // 设置头部样式
            Node header = dialogPane.lookup(".header-panel");
            if (header != null) {
                header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
            }
            // 设置内容样式
            Node content1 = dialogPane.lookup(".content");
            if (content1 != null) {
                content1.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
            }
            // 添加按钮
            ButtonType restartButton = new ButtonType("RESTART");
            ButtonType exitButton = new ButtonType("EXIT");
            alert.getButtonTypes().setAll(restartButton, exitButton);

            // 处理按钮点击事件
            alert.showAndWait().ifPresent(response -> {
                if (response == restartButton) {
                    timerLabel.setText("00:00"); // 重置计时器显示
                    if(gridType ==GridType.SQUARE){
                        gameUtils.reset(); // 调用重置游戏的方法
                    }else{
                        pane2.getChildren().clear();
                        gameUtils.reset(); // 重新初始化游戏
                        for (int row = 0; row < mRowNums; row++) {
                            for (int col = 0; col < mColumnNums; col++) {
                                Hexagon hexButton = new Hexagon(col, row);
                                setHexButtonImage(hexButton, MineType.MINE_STATUS_BLANK, pane2);
                                pane2.getChildren().add(hexButton);
                                final int ii = row;
                                final int jj = col;
                                hexButton.setOnMouseClicked(event -> {
                                    switch (event.getButton()) {
                                        case PRIMARY: leftClick(ii, jj); break;
                                        case SECONDARY: rightClick(ii, jj); break;
                                        default: break;
                                    }
                                });
                                hexButton.setOnDragOver(event -> {
                                    if (event.getGestureSource() != hexButton && event.getDragboard().hasString()) {
                                        event.acceptTransferModes(TransferMode.COPY);
                                    }
                                    event.consume();
                                });
                                hexButton.setOnDragDropped(event -> {
                                    Dragboard db = event.getDragboard();
                                    boolean success = false;
                                    if (db.hasString()) {
                                        String content2 = db.getString();
                                        if (content2.equals("Flag")) {
                                            gameUtils.drageFlag(ii, jj);  // 调用 drageFlag 方法
                                            success = true;
                                        }
                                    }
                                    event.setDropCompleted(success);
                                    event.consume();
                                });
                            }
                        }
                    }

                    isClickComplete = true; // 允许点击
                    gameStarted = false; // 游戏未开始
                } else if (response == exitButton) {
                    Platform.exit(); // 退出应用
                }
            });
//            alert.showAndWait();
        }

        @Override
        public void onLeftClick(MineBean mineBean, int i, int j) {
            if (gridType == GridType.SQUARE) {
                setButtonImage(buttonArr[i][j], mineBean.getMineCount());
            } else if (gridType == GridType.HEXAGON) {
//                for (Node node : pane2.getChildren()) { //看点击的类型
//                    System.out.println(node.getClass().getSimpleName());
//                }
                Node node = pane2.getChildren().get((i * mColumnNums + j)*2 +1);
                if (node instanceof Hexagon) {
                    System.out.println("Updating hexagon at: (" + i + ", " + j + ")");
//                    System.out.println("Hexagon index in pane2: " + pane2.getChildren().indexOf(node));
                    Hexagon hexButton = (Hexagon) node;
                    setHexButtonImage(hexButton, mineBean.getMineCount(), pane2);
                }
            }
        }

        @Override
        public void onRightClick(MineBean mineBean, int i, int j) {
            if (gridType == GridType.SQUARE) {
                setButtonImage(buttonArr[i][j], mineBean.getImageStatus());
            } else if (gridType == GridType.HEXAGON) {
                Node node = pane2.getChildren().get((i * mColumnNums + j)*2 +1);
                if (node instanceof Hexagon) {
                    System.out.println("Updating hexagon at: (" + i + ", " + j + ")");
//                    System.out.println("Hexagon index in pane2: " + pane2.getChildren().indexOf(node));
                    Hexagon hexButton = (Hexagon) node;
                    setHexButtonImage(hexButton, mineBean.getImageStatus(), pane2);
                }
//                else {
//                    System.out.println("错误: 节点不是 Hexagon 类型，实际类型为: " + node.getClass().getSimpleName());
//                }
            }
        }
    };

    private void initButtons() {
        isClickComplete = true;
        if (buttonArr == null) {
            buttonArr = new Button[mRowNums][mColumnNums];
        }
        for (int i = 0; i < mRowNums; i++) {
            for (int j = 0; j < mColumnNums; j++) {
                setButtonImage(buttonArr[i][j], MineType.MINE_STATUS_BLANK);
            }
        }
    }

    private void updateTimer() {
        if (gameStarted && !isPaused) {
            long elapsedTime = System.currentTimeMillis() - startTime;
            long seconds = (elapsedTime / 1000) % 60;
            long minutes = (elapsedTime / (1000 * 60)) % 60;
            timerLabel.setText(String.format("%02d:%02d", minutes, seconds)); //update show
        }
    }

}
