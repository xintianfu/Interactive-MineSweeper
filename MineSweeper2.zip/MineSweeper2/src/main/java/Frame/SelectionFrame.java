package Frame;

import MineBean.MineImage;
import MineBean.MineType;
import javafx.animation.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import Frame.GameFrame;
import MineArithmetic.Arithmetic.GridType;
import javafx.util.Duration;

import java.net.URL;

public class SelectionFrame extends Application {
    Image checkImage = new Image(getClass().getResource("/images/gif.gif").toExternalForm());
    Image checkingImage = new Image(getClass().getResource("/images/checking.png").toExternalForm());

    // 自定义鼠标指针
    ImageCursor checkCursor = new ImageCursor(checkImage, checkImage.getWidth() / 2, checkImage.getHeight() / 2);
    ImageCursor checkingCursor = new ImageCursor(checkingImage, checkingImage.getWidth() / 2, checkingImage.getHeight() / 2);


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("选择页面");
        BorderPane root = new BorderPane();

        // 创建 ImageView 并设置背景图片
        ImageView background = new ImageView(new Image("file:///D:/IDEA/MineSweeper1/src/main/resources/images/1.jpg"));
        background.setFitWidth(512); // 设置宽度
        background.setFitHeight(512); // 设置高度
        background.setOpacity(0.5); // 设置透明度
        // 添加 GaussianBlur 效果以虚化边缘
        GaussianBlur blur = new GaussianBlur();
        blur.setRadius(5); // 设置虚化的半径
        background.setEffect(blur); // 将虚化效果应用到背景图片
        // 创建渐变动画
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(3000), background);
        fadeTransition.setFromValue(1.0); // 从不透明开始
        fadeTransition.setToValue(0.3); // 渐变到几乎透明
        fadeTransition.setCycleCount(FadeTransition.INDEFINITE); // 无限循环
        fadeTransition.setAutoReverse(true); // 自动反转

        // 创建 ColorAdjust 效果
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setBrightness(0); // 初始亮度

// 将 ColorAdjust 应用到 ImageView
        background.setEffect(colorAdjust);

// 创建颜色变化动画
        Timeline colorAnimation = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(colorAdjust.brightnessProperty(), 0)),
                new KeyFrame(Duration.seconds(2), new KeyValue(colorAdjust.brightnessProperty(), 0.5)), // 明亮
                new KeyFrame(Duration.seconds(4), new KeyValue(colorAdjust.brightnessProperty(), 0)) // 恢复原状
        );
        colorAnimation.setCycleCount(Timeline.INDEFINITE);
        colorAnimation.setAutoReverse(true);
        colorAnimation.play();

// 创建渐变动画
        FadeTransition fadeTransition1 = new FadeTransition(Duration.millis(3000), background);
        fadeTransition1.setFromValue(1.0); // 从不透明开始
        fadeTransition1.setToValue(0.3); // 渐变到几乎透明
        fadeTransition1.setCycleCount(FadeTransition.INDEFINITE); // 无限循环
        fadeTransition1.setAutoReverse(true); // 自动反转

// 开始播放动画
        fadeTransition.play();

        // 开始播放动画
        fadeTransition1.play();


        // 将背景 ImageView 添加到根节点
        root.getChildren().add(background);
        root.setTop(topLayout());
        root.setCenter(centerLayout(primaryStage));

        Scene scene1 = new Scene(root, 512, 512);
        URL url = getClass().getResource("/selectionframe.css");
        if (url != null) {
            scene1.getStylesheets().add(url.toExternalForm());
            System.out.println("found it!");
        } else {
            System.out.println("Resource not found: selectionframe.css");
        }

        primaryStage.setScene(scene1);
        primaryStage.show();

    }

    public HBox topLayout() {
        HBox pane = new HBox(10); //间距为10
        pane.setPadding(new Insets(15,12,15,12));
        pane.setAlignment(Pos.CENTER);
        pane.getStyleClass().add("top-pane"); // 添加背景颜色的样式
        // 创建logo并设置图像
        Label logo = new Label();
        setLabelImage(logo, MineType.MINE_LOGO);
//        logo.getStyleClass().add("logo"); //logo加css

        Label SelectionLabel = new Label("SELECTION MODE");
        SelectionLabel.getStyleClass().add("selection-label");
        // 使用一个Region作为左边和右边的占位符
        Region leftSpacer = new Region();
//        leftSpacer.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        Region rightSpacer = new Region();
        leftSpacer.setPrefWidth(40); // 设置首选宽度
//        HBox.setHgrow(leftSpacer, Priority.ALWAYS); // 左侧占位符扩展
        HBox.setHgrow(rightSpacer, Priority.ALWAYS); // 右侧占位符扩展

        pane.getChildren().addAll(logo,leftSpacer,SelectionLabel,rightSpacer);

        // 给 leftBox 添加边框
//        pane.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        return pane;
    }

    public VBox centerLayout(Stage primaryStage){

        VBox centerlayout = new VBox(45); //元素之间的上下
//        centerlayout.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
//        centerlayout.setPadding(new Insets(10));
        centerlayout.setAlignment(Pos.CENTER);
        centerlayout.setOnMouseEntered(event -> {
            centerlayout.setCursor(checkCursor);
        });
        Button easyButton = new Button("EASY");
        setButtonCursor(easyButton); // 设置光标事件
        easyButton.setOnAction(event -> {
            GameFrame gameFrame = new GameFrame(10, 10, 10, GridType.SQUARE);
            gameFrame.initParentStage(primaryStage);
            gameFrame.start(new Stage());
        });
        Button mediumButton = new Button("MEDIUM");
        setButtonCursor(mediumButton); // 设置光标事件
        mediumButton.setOnAction(event -> {
            GameFrame gameFrame = new GameFrame(20, 20, 40, GridType.SQUARE);
            gameFrame.initParentStage(primaryStage);
            gameFrame.start(new Stage());
        });
        Button advanceButton = new Button("ADVANCE");
        setButtonCursor(advanceButton);
        advanceButton.setOnAction(event -> {
            GameFrame gameFrame = new GameFrame(20, 20, 40, GridType.HEXAGON);
            gameFrame.initParentStage(primaryStage);
            gameFrame.start(new Stage());
        });
        Button customizeButton = new Button("CUSTOMIZE");
        setButtonCursor(customizeButton);
        customizeButton.setOnAction(event -> {
            // 创建 CustomizeFrame 对象
            CustomizeFrame customizeFrame = new CustomizeFrame();  // Create an instance of CustomizeFrame
            customizeFrame.start(new Stage());  // Start the CustomizeFrame in the new Stage
            // 关闭当前 SelectionFrame 的 Stage (primaryStage)
            primaryStage.close();
        });

        centerlayout.getChildren().addAll(easyButton,mediumButton,advanceButton,customizeButton);
        // 添加抖动动画
        addShakeAnimation(easyButton);
        addShakeAnimation(mediumButton);
        addShakeAnimation(advanceButton);
        addShakeAnimation(customizeButton);

        return centerlayout;
    }
    public void setLabelImage(Label label, int flag) {
        if (label == null) {
            return;
        }
        ImageView icon = MineImage.getImageView(100, 100, flag);
        icon.setFitWidth(40); //长
        icon.setFitHeight(40); //宽
        label.setGraphic(icon);
    }
    private void addShakeAnimation(Button button) {
        // 左右摇摆动画
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), button);
        translateTransition.setFromX(-5);  // 从-5像素开始
        translateTransition.setToX(5);      // 到5像素结束
        translateTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环
        translateTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        translateTransition.setAutoReverse(true);

        // 旋转动画
        RotateTransition rotateTransition = new RotateTransition(Duration.millis(200), button);
        rotateTransition.setFromAngle(-5);  // 从-5度开始
        rotateTransition.setToAngle(5);      // 到5度结束
        rotateTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环
        rotateTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        rotateTransition.setAutoReverse(true);

        // 鼠标悬停时同时开始动画
        button.setOnMouseEntered(e -> {
            translateTransition.play();
            rotateTransition.play();
        });
        // 鼠标移出时停止动画
        button.setOnMouseExited(e -> {
            translateTransition.stop();
            rotateTransition.stop();
            button.setTranslateX(0); // 重置X轴位置
            button.setRotate(0);      // 重置旋转角度
        });
    }

    // 创建一个方法来设置按钮的光标事件
    private void setButtonCursor(Button button) {
        button.setCursor(checkCursor); // 设置默认光标
        button.setOnMousePressed(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                button.setCursor(checkingCursor); // 设置为checking.png
            }
        });
        button.setOnMouseReleased(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                button.setCursor(checkCursor); // 恢复为check.png
            }
        });
    }


}
