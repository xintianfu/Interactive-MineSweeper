package Frame;

import MineBean.MineImage;
import MineBean.MineType;
import javafx.animation.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import Frame.GameFrame;
import MineArithmetic.Arithmetic.GridType;
import javafx.util.Duration;

import java.net.URL;

import java.net.URL;

public class CustomizeFrame extends Application {

    private GridType gridType;
    int row = 0;
    int col = 0;
    private Label hintLabel; // 将 hintLabel 定义为实例变量Define hintLabel as an instance variable

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        primaryStage.setTitle("自定义页面");

        BorderPane root = new BorderPane();
        // 创建 ImageView 并设置背景图片
        ImageView background = new ImageView(new Image("file:///D:/IDEA/MineSweeper1/src/main/resources/images/1.jpg"));
        background.setFitWidth(512); // 设置宽度
        background.setFitHeight(512); // 设置高度
        background.setOpacity(0.4); // 设置透明度
        // 添加 GaussianBlur 效果以虚化边缘 Add the GaussianBlur effect to blur the edges
        GaussianBlur blur = new GaussianBlur();
        blur.setRadius(5); // 设置虚化的半径Set the radius of the blur
        background.setEffect(blur); // 将虚化效果应用到背景图片
        // 创建渐变动画Create gradient animation
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(3000), background);
        fadeTransition.setFromValue(1.0); // 从不透明开始
        fadeTransition.setToValue(0.3); // 渐变到几乎透明
        fadeTransition.setCycleCount(FadeTransition.INDEFINITE); // 无限循环
        fadeTransition.setAutoReverse(true); // 自动反转

        // 创建 ColorAdjust 效果
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setBrightness(0); // 初始亮度Initial brightness

// 将 ColorAdjust 应用到 ImageView
        background.setEffect(colorAdjust);

// 创建颜色变化动画Create a color change animation
        Timeline colorAnimation = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(colorAdjust.brightnessProperty(), 0)),
                new KeyFrame(Duration.seconds(2), new KeyValue(colorAdjust.brightnessProperty(), 0.5)), // 明亮
                new KeyFrame(Duration.seconds(4), new KeyValue(colorAdjust.brightnessProperty(), 0)) // 恢复原状
        );
        colorAnimation.setCycleCount(Timeline.INDEFINITE);
        colorAnimation.setAutoReverse(true);
        colorAnimation.play();

// 创建渐变动画
        FadeTransition fadeTransition1 = new FadeTransition(Duration.millis(3000), background);
        fadeTransition1.setFromValue(1.0); // 从不透明开始
        fadeTransition1.setToValue(0.3); // 渐变到几乎透明
        fadeTransition1.setCycleCount(FadeTransition.INDEFINITE); // 无限循环
        fadeTransition1.setAutoReverse(true); // 自动反转

// 开始播放动画
        fadeTransition.play();

        // 开始播放动画
        fadeTransition1.play();

        // 将背景 ImageView 添加到根节点
        root.getChildren().add(background);
        root.setTop(topLayout());
        root.setCenter(centerLayout(primaryStage));

        Scene scene1 = new Scene(root, 512, 512);
        URL url = getClass().getResource("/customize.css");
        if (url != null) {
            scene1.getStylesheets().add(url.toExternalForm());
//            System.out.println("found it!");
        } else {
            System.out.println("Resource not found: customize.css");
        }

        primaryStage.setScene(scene1);
        primaryStage.show();
    }
    public HBox topLayout() {
        HBox pane = new HBox(10); //间距为10
        pane.setPadding(new Insets(15,12,15,12));
        pane.setAlignment(Pos.CENTER);
        pane.getStyleClass().add("top-pane"); // 添加背景颜色的样式
        // 创建logo并设置图像
        Label logo = new Label();
        setLabelImage(logo, MineType.MINE_LOGO);
        Label CustomiazeLabel = new Label("CUSTOMIZE MODE");
        CustomiazeLabel.getStyleClass().add("selection-label");
        // 使用一个Region作为左边和右边的占位符Use a Region as a placeholder for the left and right sides
        Region leftSpacer = new Region();
//        leftSpacer.setBorder(new Border(new BorderStroke(
//                Color.BLUE,                     // 边框颜色
//                BorderStrokeStyle.SOLID,        // 边框样式
//                null,                           // 边角半径
//                new BorderWidths(2)             // 边框宽度
//        )));
        Region rightSpacer = new Region();
        leftSpacer.setPrefWidth(80);
        HBox.setHgrow(rightSpacer, Priority.ALWAYS);

        pane.getChildren().addAll(logo,leftSpacer,CustomiazeLabel,rightSpacer);
        return pane;
    }
    public void setLabelImage(Label label, int flag) {
        if (label == null) {
            return;
        }
        ImageView icon = MineImage.getImageView(100, 100, flag);
        icon.setFitWidth(40); //长
        icon.setFitHeight(40); //宽
        label.setGraphic(icon);
    }

    public VBox centerLayout(Stage primaryStage){
        VBox centerlayout = new VBox(40);
        centerlayout.setPadding(new Insets(20));
        centerlayout.setAlignment(Pos.CENTER);

        HBox Gridsize = new HBox(20);
        Label gridsize = new Label("Grid Size:");
        Label gridsizeX = new Label("X");
        gridsize.getStyleClass().add("label");
        gridsizeX.getStyleClass().add("label");
        TextField textField1 = new TextField();
        TextField textField2 = new TextField();
        addShakeAnimation(textField1);
        addShakeAnimation(textField2);
        textField1.getStyleClass().add("text-field");
//        textField1.setPrefWidth(75); // 设置文本框的宽度为150像素
//        textField2.setPrefWidth(75); // 设置文本框的宽度为150像素
        textField1.setPromptText("row..."); // 提示文本
        textField2.setPromptText("col...");
        Gridsize.getChildren().addAll(gridsize,textField1,gridsizeX,textField2);
        Gridsize.setAlignment(Pos.CENTER);
        Gridsize.setPadding(new Insets(10));

        // 创建 Tooltip
        Tooltip tooltipp = new Tooltip("Keep the rows and columns within 20.\nAfter all, your windows are limited.");
        gridsize.setOnMouseEntered(e -> tooltipp.show(gridsize, e.getScreenX(), e.getScreenY() + 10));
        gridsize.setOnMouseExited(e -> tooltipp.hide());

        HBox Gridshape = new HBox(20);
        Label gridshape = new Label("Grid Shape:");
        gridshape.getStyleClass().add("abel");
        Button sqButton = new Button("Square");
        Button hexButton = new Button("Hexagon");
        sqButton.getStyleClass().add("buttonsh");
        hexButton.getStyleClass().add("buttonsh");
        Gridshape.getChildren().addAll(gridshape,sqButton,hexButton);
        Gridshape.setAlignment(Pos.CENTER);
        Gridshape.setPadding(new Insets(10));
        // 用于显示提示信息的 Label   Label used to display prompt information
        hintLabel = new Label();
        hintLabel.getStyleClass().add("HINT");
        updateHint(""); // 没有提示文本
        addShakeAnimationHint(hintLabel); // 为hintLabel添加抖动动画
        handleShakeAnimationHint(hintLabel); // 启动动画监听

        sqButton.setOnAction(event -> {
            gridType = GridType.SQUARE;
            System.out.println(gridType);
            String text1 = textField1.getText(); // 获取文本框中的文本
            String text2 = textField2.getText();
            row = Integer.parseInt(text1); // 转换为整数
            System.out.println("row: " + row);
            col = Integer.parseInt(text2); // 转换为整数
            System.out.println("col: " + col);

            if (row > 20 || col > 20) {
                hintLabel.setText("Rows and columns cannot exceed 20!!");
            } else {
                int totalGrids = row * col;
                int minMines = (int)(totalGrids * 0.1);  // 最少 10% 的网格是炸弹
                int maxMines = (int)(totalGrids * 0.3);  // 最多 30% 的网格是炸弹
                // 更新提示信息
                hintLabel.setText("mines should between " + minMines + " and " + maxMines);
            }
        });
        hexButton.setOnAction(event -> {
            gridType = GridType.HEXAGON;
            String text1 = textField1.getText(); // 获取文本框中的文本
            String text2 = textField2.getText();
            row = Integer.parseInt(text1); // 转换为整数
            System.out.println("row: " + row);
            col = Integer.parseInt(text2); // 转换为整数
            System.out.println("col: " + col);
            if (row > 20 || col > 20) {
                hintLabel.setText("Rows and columns cannot exceed 20!!");
            } else {
                int totalGrids = row * col;
                int minMines = (int)(totalGrids * 0.1);  // 最少 10% 的网格是炸弹
                int maxMines = (int)(totalGrids * 0.3);  // 最多 30% 的网格是炸弹
                // 更新提示信息
                hintLabel.setText("mines should between " + minMines + " and " + maxMines);
            }
        });
        addShakeAnimation(sqButton);
        addShakeAnimation(hexButton);

        HBox Minenum = new HBox(20);
        Label minenum = new Label("Number of mines:");
        minenum.getStyleClass().add("label");



        TextField minesnumtext = new TextField();
        addShakeAnimation(minesnumtext);
//        minesnumtext.setPromptText(); // 提示文本
        // 创建 Tooltip
        Tooltip tooltip3 = new Tooltip("The number of bombs should be between 10% and 30% of the total count!");
        minenum.setOnMouseEntered(e -> tooltip3.show(minenum, e.getScreenX(), e.getScreenY() + 10));
        minenum.setOnMouseExited(e -> tooltip3.hide());

        minesnumtext.setPrefWidth(50); // 设置文本框的宽度为150像素
        Minenum.getChildren().addAll(minenum,minesnumtext);
        Minenum.setAlignment(Pos.CENTER);
        Minenum.setPadding(new Insets(10));


        Button startGameButton = new Button("START");
        startGameButton.setOnAction(event -> {
            String text1 = textField1.getText(); // 获取文本框中的文本
            String text2 = textField2.getText();
            String minenums = minesnumtext.getText(); // 获取文本框中的文本
            try {
                row = Integer.parseInt(text1); // 转换为整数
                System.out.println("row: " + row);
                col = Integer.parseInt(text2); // 转换为整数
                System.out.println("col: " + col);

                int minenumm = Integer.parseInt(minenums); // 转换为整数

                System.out.println("minenum: " + minenumm);
                int totalGrids = row * col;
                int minMines = (int)(totalGrids * 0.1);  // 最少 10% 的网格是炸弹
                int maxMines = (int)(totalGrids * 0.3);  // 最多 30% 的网格是炸弹


                System.out.println("minenum: " + minenumm);

                if(row > 20 || col > 20){
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Number exceeded");
                    alert.setHeaderText(null);
                    alert.setContentText("Rows and columns must be kept within 20.");
                    // 设置 CSS 样式
                    DialogPane dialogPane = alert.getDialogPane();
                    dialogPane.setStyle("-fx-background-color: #333; " +
                            "-fx-text-fill: #FFF; " +
                            "-fx-border-color: #FF0000; " +
                            "-fx-border-width: 2px; " +
                            "-fx-padding: 10; " +
                            "-fx-font-size: 14px; " +
                            "-fx-font-family: 'Courier New';");
                    // 设置头部样式
                    Node header = dialogPane.lookup(".header-panel");
                    if (header != null) {
                        header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
                    }
                    // 设置内容样式
                    Node content = dialogPane.lookup(".content");
                    if (content != null) {
                        content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
                    }
                    shakeAlert(dialogPane);
                    // 修改按钮文本为 "Confirm"
                    ButtonType confirmButton = new ButtonType("Confirm");
                    alert.getButtonTypes().setAll(confirmButton);
                    Button yesButtonNode = (Button) alert.getDialogPane().lookupButton(confirmButton);
                    if (yesButtonNode != null) {
                        yesButtonNode.setStyle("-fx-background-color: #1C1C1C; " + // 按钮背景颜色
                                "-fx-text-fill: #FFFFFF; " + // 按钮文字颜色
                                "-fx-border-color: #444444; " + // 边框颜色
                                "-fx-border-width: 2px; " + // 边框宽度
                                "-fx-border-radius: 5px; " + // 边框圆角
                                "-fx-padding: 10; " + // 内边距
                                "-fx-font-size: 14px; " + // 字体大小
                                "-fx-font-family: 'Courier New'; " + // 字体类型
                                "-fx-background-radius: 5; " + // 圆角
                                "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1);"); // 阴影效果
                    }
//                    System.out.println("当前样式类: " + dialogPane.getStyleClass());
                    alert.showAndWait();
                }
                else if (minenumm < minMines || minenumm > maxMines) {
                    System.out.println("number of mine should be between " + minMines + " and " + maxMines + " ！");
                    // 弹出提示框提醒用户
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Invalid number of bombs");
                    alert.setHeaderText(null);
                    alert.setContentText("number of mine should be between " + minMines + " and " + maxMines + " ！");
                    // 设置 CSS 样式
                    DialogPane dialogPane = alert.getDialogPane();
                    dialogPane.setStyle("-fx-background-color: #333; " +
                            "-fx-text-fill: #FFF; " +
                            "-fx-border-color: #FF0000; " +
                            "-fx-border-width: 2px; " +
                            "-fx-padding: 10; " +
                            "-fx-font-size: 14px; " +
                            "-fx-font-family: 'Courier New';");
                    // 设置头部样式
                    Node header = dialogPane.lookup(".header-panel");
                    if (header != null) {
                        header.setStyle("-fx-background-color: #2a2a2a; -fx-text-fill: #00ff00;");
                    }
                    // 设置内容样式
                    Node content = dialogPane.lookup(".content");
                    if (content != null) {
                        content.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 14px; -fx-padding: 10px; -fx-text-fill: #FFF;");
                    }
                    shakeAlert(dialogPane);
                    // 修改按钮文本为 "Confirm"
                    ButtonType confirmButton = new ButtonType("Confirm");
                    alert.getButtonTypes().setAll(confirmButton);
                    Button yesButtonNode = (Button) alert.getDialogPane().lookupButton(confirmButton);
                    if (yesButtonNode != null) {
                        yesButtonNode.setStyle("-fx-background-color: #1C1C1C; " + // 按钮背景颜色
                                "-fx-text-fill: #FFFFFF; " + // 按钮文字颜色
                                "-fx-border-color: #444444; " + // 边框颜色
                                "-fx-border-width: 2px; " + // 边框宽度
                                "-fx-border-radius: 5px; " + // 边框圆角
                                "-fx-padding: 10; " + // 内边距
                                "-fx-font-size: 14px; " + // 字体大小
                                "-fx-font-family: 'Courier New'; " + // 字体类型
                                "-fx-background-radius: 5; " + // 圆角
                                "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 5, 0, 0, 1);"); // 阴影效果
                    }
//                    System.out.println("当前样式类: " + dialogPane.getStyleClass());
                    alert.showAndWait();
                }
                else if (gridType != null) {
                    GameFrame gameFrame = new GameFrame(row, col, minenumm, gridType);
                    gameFrame.initParentStage(primaryStage);
                    gameFrame.start(new Stage());
                } else {
                    System.out.println("Please select a grid type first!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number!"); // 处理异常
            }
        });
        addShakeAnimation2(startGameButton);

        centerlayout.getChildren().addAll(Gridsize,Gridshape,Minenum,hintLabel,startGameButton);
        return centerlayout;
    }
    // 添加抖动效果的方法
    private void shakeAlert(Node alertContent) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(500), alertContent);
        scaleTransition.setFromX(1);
        scaleTransition.setFromY(1);
        scaleTransition.setToX(1.05); // 放大
        scaleTransition.setToY(1.05); // 放大
        scaleTransition.setCycleCount(6); // 设置抖动的次数
        scaleTransition.setAutoReverse(true); // 启用自动反转
        scaleTransition.play();
    }
    // 方法用于更新提示文本
    public void updateHint(String hintText) {
        hintLabel.setText(hintText);

        if (hintText.isEmpty()) {
            hintLabel.getStyleClass().remove("active"); // 移除背景
        } else {
            if (!hintLabel.getStyleClass().contains("active")) {
                hintLabel.getStyleClass().add("active"); // 添加背景
            }
        }
    }
    private void addShakeAnimation2(Button button) {

        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1);  // 从正常大小开始
        scaleTransition.setToX(1.1);   // 到1.1倍大小结束
        scaleTransition.setFromY(1);  // 从正常大小开始
        scaleTransition.setToY(1.1);   // 到1.1倍大小结束
        scaleTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环
        scaleTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        scaleTransition.setAutoReverse(true);


        // 鼠标悬停时同时开始动画
        button.setOnMouseEntered(e -> {
            scaleTransition.play();
        });
        // 鼠标移出时停止动画
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1);     // 重置X轴缩放
            button.setScaleY(1);     // 重置Y轴缩放
        });
    }
    private void addShakeAnimation(Node node) {
        // 左右摇摆动画
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), node);
        translateTransition.setFromX(-5);  // 从-5像素开始
        translateTransition.setToX(5);      // 到5像素结束
        translateTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环
        translateTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        translateTransition.setAutoReverse(true);

        // 旋转动画
        RotateTransition rotateTransition = new RotateTransition(Duration.millis(200), node);
        rotateTransition.setFromAngle(-5);  // 从-5度开始
        rotateTransition.setToAngle(5);      // 到5度结束
        rotateTransition.setCycleCount(Timeline.INDEFINITE); // 无限循环
        rotateTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        rotateTransition.setAutoReverse(true);

        // 鼠标悬停时同时开始动画
        node.setOnMouseEntered(e -> {
            translateTransition.play();
            rotateTransition.play();
        });
        // 鼠标移出时停止动画
        node.setOnMouseExited(e -> {
            translateTransition.stop();
            rotateTransition.stop();
            node.setTranslateX(0); // 重置X轴位置
            node.setRotate(0);      // 重置旋转角度
        });
    }
    private void addShakeAnimationHint(Node node) {
        // 左右摇摆动画
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(200), node);
        translateTransition.setFromX(-5);  // 从-5像素开始
        translateTransition.setToX(5);     // 到5像素结束
        translateTransition.setCycleCount(6); // 无限循环
        translateTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        translateTransition.setAutoReverse(true);

        // 旋转动画
        RotateTransition rotateTransition = new RotateTransition(Duration.millis(200), node);
        rotateTransition.setFromAngle(-5);  // 从-5度开始
        rotateTransition.setToAngle(5);     // 到5度结束
        rotateTransition.setCycleCount(6); // 无限循环
        rotateTransition.setInterpolator(Interpolator.LINEAR); // 线性插值
        rotateTransition.setAutoReverse(true);

        // 放大动画
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(1000), node);
        scaleTransition.setFromX(0.1);  // 原始大小
        scaleTransition.setFromY(0.1);
        scaleTransition.setToX(1.2);  // 放大到1.2倍
        scaleTransition.setToY(1.2);
        scaleTransition.setCycleCount(1); // 循环6次
//        scaleTransition.setAutoReverse(true); // 回到原始大小

        // 动画完成后重置位置和旋转角度
        translateTransition.setOnFinished(e -> {
            node.setTranslateX(0);  // 重置X轴位置
        });

        rotateTransition.setOnFinished(e -> {
            node.setRotate(0);  // 重置旋转角度
        });

        // 当文本框有内容时播放动画
        node.getProperties().put("translateTransition", translateTransition);
        node.getProperties().put("rotateTransition", rotateTransition);
        node.getProperties().put("scaleTransition", scaleTransition);
    }

    // 用于启动或停止动画的方法
    private void handleShakeAnimationHint(Label label) {
        // 获取为这个Label设置的动画
        TranslateTransition translateTransition = (TranslateTransition) label.getProperties().get("translateTransition");
        RotateTransition rotateTransition = (RotateTransition) label.getProperties().get("rotateTransition");
        ScaleTransition scaleTransition = (ScaleTransition) label.getProperties().get("scaleTransition");

        // 监听Label的文本属性
        label.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.isEmpty()) {
                // 当Label有文本时开始播放动画
                translateTransition.play();
                rotateTransition.play();
                scaleTransition.play();
            } else {
                // 当Label没有文本时停止动画并重置位置和旋转角度
                translateTransition.stop();
                rotateTransition.stop();
                scaleTransition.stop();
                label.setTranslateX(0);  // 重置X轴位置
                label.setRotate(0);      // 重置旋转角度
            }
        });
    }
}
